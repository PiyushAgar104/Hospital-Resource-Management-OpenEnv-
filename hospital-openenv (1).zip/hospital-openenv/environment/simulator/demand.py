"""
Patient flow and medication demand simulator.

Models:
  - Poisson arrivals with time-of-week & seasonal variation
  - Acuity-weighted length-of-stay
  - Deterioration / mortality risk based on staffing & med supply
  - Medication consumption tied to patient census and acuity
"""
from __future__ import annotations

import math
import random
from typing import Dict, List, Optional, Tuple

import numpy as np

from environment.models import (
    BedAllocation,
    Medication,
    MedCategory,
    Patient,
    PatientAcuity,
    StaffSchedule,
    UnitType,
    HospitalUnit,
)


# ─── Constants ───────────────────────────────────────────────────────────────

ACUITY_LOS: Dict[PatientAcuity, Tuple[float, float]] = {
    PatientAcuity.LOW:      (2.0, 1.0),
    PatientAcuity.MEDIUM:   (4.5, 2.0),
    PatientAcuity.HIGH:     (7.0, 3.0),
    PatientAcuity.CRITICAL: (12.0, 5.0),
}

# Base daily admission rate per unit type
UNIT_ARRIVAL_RATES: Dict[UnitType, float] = {
    UnitType.EMERGENCY: 8.0,
    UnitType.GENERAL:   4.0,
    UnitType.SURGERY:   2.5,
    UnitType.ICU:       1.5,
}

# Day-of-week multiplier (Mon=0 … Sun=6)
DOW_MULT = [1.15, 1.10, 1.05, 1.00, 1.05, 0.80, 0.75]

# Monthly seasonal multiplier (Jan=1 … Dec=12)
MONTH_MULT = [1.20, 1.15, 1.05, 0.95, 0.90, 0.85,
              0.85, 0.88, 0.95, 1.00, 1.10, 1.25]

# Medication consumption per patient-day by acuity
MED_CONSUMPTION: Dict[PatientAcuity, Dict[MedCategory, Tuple[float, float]]] = {
    PatientAcuity.LOW: {
        MedCategory.ANALGESIC:    (1.0, 0.3),
        MedCategory.ANTIBIOTIC:   (0.5, 0.2),
        MedCategory.CARDIAC:      (0.2, 0.1),
        MedCategory.SEDATIVE:     (0.1, 0.05),
        MedCategory.BLOOD_PRODUCT: (0.0, 0.0),
    },
    PatientAcuity.MEDIUM: {
        MedCategory.ANALGESIC:    (2.0, 0.5),
        MedCategory.ANTIBIOTIC:   (1.5, 0.4),
        MedCategory.CARDIAC:      (0.8, 0.3),
        MedCategory.SEDATIVE:     (0.5, 0.2),
        MedCategory.BLOOD_PRODUCT: (0.1, 0.05),
    },
    PatientAcuity.HIGH: {
        MedCategory.ANALGESIC:    (3.0, 0.7),
        MedCategory.ANTIBIOTIC:   (3.0, 0.6),
        MedCategory.CARDIAC:      (2.0, 0.5),
        MedCategory.SEDATIVE:     (1.5, 0.4),
        MedCategory.BLOOD_PRODUCT: (0.5, 0.2),
    },
    PatientAcuity.CRITICAL: {
        MedCategory.ANALGESIC:    (5.0, 1.0),
        MedCategory.ANTIBIOTIC:   (6.0, 1.2),
        MedCategory.CARDIAC:      (4.0, 0.8),
        MedCategory.SEDATIVE:     (4.0, 0.8),
        MedCategory.BLOOD_PRODUCT: (2.0, 0.6),
    },
}


class DemandSimulator:
    """
    Simulates realistic hospital patient flow and medication demand.

    Args:
        units:       List of hospital units in the scenario.
        medications: List of medications tracked.
        seed:        RNG seed for reproducibility.
        scenario:    'normal' | 'surge' | 'epidemic' modifies arrival rates.
    """

    def __init__(
        self,
        units: List[HospitalUnit],
        medications: List[Medication],
        seed: int = 42,
        scenario: str = "normal",
    ) -> None:
        self.units = {u.id: u for u in units}
        self.medications = {m.id: m for m in medications}
        self.rng = random.Random(seed)
        self.np_rng = np.random.default_rng(seed)
        self.scenario = scenario
        self._scenario_mult = {"normal": 1.0, "surge": 1.6, "epidemic": 2.2}.get(
            scenario, 1.0
        )

    # ── Arrival generation ─────────────────────────────────────────────────

    def generate_admissions(
        self,
        day: int,
        unit_id: str,
        current_census: int,
        bed_capacity: int,
    ) -> List[Patient]:
        """Generate new patient admissions for a given unit and day."""
        unit = self.units[unit_id]
        dow = day % 7
        month = ((day % 365) // 30)  # approximate month index 0–11
        month = min(month, 11)

        base_rate = UNIT_ARRIVAL_RATES[unit.unit_type]
        rate = (
            base_rate
            * DOW_MULT[dow]
            * MONTH_MULT[month]
            * self._scenario_mult
        )
        # Add random surge events (flu outbreak, mass casualty, etc.)
        if self.rng.random() < 0.03:
            rate *= self.rng.uniform(1.5, 2.5)

        n_arrivals = self.np_rng.poisson(rate)

        # Respect bed capacity with soft cap
        available_beds = max(0, bed_capacity - current_census)
        n_arrivals = min(n_arrivals, available_beds + 2)  # +2 = hallway beds

        patients = []
        for _ in range(n_arrivals):
            acuity = self._sample_acuity(unit.unit_type)
            los_mean, los_std = ACUITY_LOS[acuity]
            los = max(1, int(self.np_rng.normal(los_mean, los_std)))
            meds = self._sample_med_needs(acuity)
            det_risk = self._base_deterioration_risk(acuity)
            patients.append(
                Patient(
                    acuity=acuity,
                    unit_id=unit_id,
                    admission_day=day,
                    expected_los=los,
                    meds_needed=meds,
                    deterioration_risk=det_risk,
                )
            )
        return patients

    def _sample_acuity(self, unit_type: UnitType) -> PatientAcuity:
        weights: Dict[UnitType, List[float]] = {
            UnitType.EMERGENCY: [0.30, 0.40, 0.20, 0.10],
            UnitType.GENERAL:   [0.50, 0.35, 0.12, 0.03],
            UnitType.SURGERY:   [0.20, 0.45, 0.30, 0.05],
            UnitType.ICU:       [0.05, 0.20, 0.40, 0.35],
        }
        acuities = list(PatientAcuity)
        w = weights[unit_type]
        return self.rng.choices(acuities, weights=w, k=1)[0]

    def _sample_med_needs(self, acuity: PatientAcuity) -> Dict[str, int]:
        needs: Dict[str, int] = {}
        category_map: Dict[MedCategory, List[str]] = {}
        for m in self.medications.values():
            category_map.setdefault(m.category, []).append(m.id)

        consumption = MED_CONSUMPTION[acuity]
        for category, med_ids in category_map.items():
            if not med_ids:
                continue
            mean, std = consumption.get(category, (0.0, 0.0))
            if mean == 0:
                continue
            daily_qty = max(0, int(self.np_rng.normal(mean, std)))
            if daily_qty > 0:
                chosen = self.rng.choice(med_ids)
                needs[chosen] = daily_qty
        return needs

    def _base_deterioration_risk(self, acuity: PatientAcuity) -> float:
        base = {
            PatientAcuity.LOW:      0.02,
            PatientAcuity.MEDIUM:   0.05,
            PatientAcuity.HIGH:     0.12,
            PatientAcuity.CRITICAL: 0.22,
        }
        return base[acuity]

    # ── Patient outcomes ───────────────────────────────────────────────────

    def compute_deterioration(
        self,
        patient: Patient,
        staffing_ratio: float,     # actual staff / required staff (1.0 = adequate)
        med_supply_ratio: float,   # fulfilled med demand / total need (1.0 = full)
        day: int,
    ) -> Tuple[bool, PatientAcuity]:
        """
        Returns (deteriorated: bool, new_acuity: PatientAcuity).

        Risk increases with:
          - low staffing
          - medication shortfalls
          - longer stay (fatigue, HAI)
        """
        days_admitted = day - patient.admission_day
        fatigue_factor = 1.0 + 0.02 * days_admitted

        # Staffing effect: understaffed by 50% → 3× risk
        staffing_factor = max(0.5, 2.0 - staffing_ratio) if staffing_ratio < 1.0 else 1.0

        # Med supply effect: 0% supply → 4× risk for critical meds
        med_factor = 1.0 + 3.0 * (1.0 - med_supply_ratio)

        risk = patient.deterioration_risk * fatigue_factor * staffing_factor * med_factor
        risk = min(0.95, risk)

        if self.rng.random() < risk:
            # Worsen acuity by one level
            levels = list(PatientAcuity)
            current_idx = levels.index(patient.acuity)
            new_idx = min(current_idx + 1, len(levels) - 1)
            return True, levels[new_idx]
        return False, patient.acuity

    def compute_mortality(
        self,
        patient: Patient,
        staffing_ratio: float,
        med_supply_ratio: float,
    ) -> bool:
        """Returns True if patient dies (only for CRITICAL acuity)."""
        if patient.acuity != PatientAcuity.CRITICAL:
            return False
        base = 0.05
        risk = base * max(1.0, 1.5 - staffing_ratio) * max(1.0, 2.0 - med_supply_ratio)
        return self.rng.random() < min(0.40, risk)

    def natural_discharge(self, patient: Patient, day: int) -> bool:
        """Returns True if patient naturally discharges today."""
        los = day - patient.admission_day
        if los < patient.expected_los:
            return False
        # After expected LOS, daily probability of discharge
        extra = los - patient.expected_los
        prob = 0.5 + 0.15 * extra
        return self.rng.random() < prob

    # ── Medication demand ──────────────────────────────────────────────────

    def compute_daily_med_demand(
        self, patients: List[Patient]
    ) -> Dict[str, int]:
        """Aggregate medication units needed today across all patients."""
        demand: Dict[str, int] = {}
        for p in patients:
            for med_id, qty in p.meds_needed.items():
                # Small daily variation
                actual = max(0, int(self.np_rng.normal(qty, qty * 0.15)))
                demand[med_id] = demand.get(med_id, 0) + actual
        return demand

    # ── Forecasting ───────────────────────────────────────────────────────

    def forecast_admissions(
        self, day: int, unit_id: str, horizon: int = 3
    ) -> List[Dict]:
        """Noisy forecast of admissions for next `horizon` days."""
        unit = self.units[unit_id]
        forecasts = []
        for d in range(day + 1, day + horizon + 1):
            dow = d % 7
            month = min((d % 365) // 30, 11)
            rate = (
                UNIT_ARRIVAL_RATES[unit.unit_type]
                * DOW_MULT[dow]
                * MONTH_MULT[month]
                * self._scenario_mult
            )
            noise = self.rng.uniform(0.7, 1.3)
            noisy_rate = rate * noise
            for acuity in PatientAcuity:
                w = {
                    UnitType.EMERGENCY: [0.30, 0.40, 0.20, 0.10],
                    UnitType.GENERAL:   [0.50, 0.35, 0.12, 0.03],
                    UnitType.SURGERY:   [0.20, 0.45, 0.30, 0.05],
                    UnitType.ICU:       [0.05, 0.20, 0.40, 0.35],
                }[unit.unit_type]
                idx = list(PatientAcuity).index(acuity)
                forecasts.append(
                    {
                        "day": d,
                        "unit_id": unit_id,
                        "acuity": acuity.value,
                        "expected_count": round(noisy_rate * w[idx], 1),
                    }
                )
        return forecasts
