"""
Test suite for Hospital Resource Management OpenEnv.
Uses stdlib unittest only — no external dependencies required.

Run:
    python -m unittest tests.test_env -v
    python tests/test_env.py
"""
from __future__ import annotations

import sys
import os
import unittest

# Allow running from project root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from environment import HospitalEnv
from environment.models import (
    AgentAction,
    BedTransferAction,
    DischargeAction,
    MedOrderAction,
    PatientAcuity,
    StaffAssignAction,
)
from baseline.agent import GreedyAgent, HeuristicAgent, RandomAgent


# ─── Helpers ─────────────────────────────────────────────────────────────────

def make_env() -> HospitalEnv:
    return HospitalEnv()


# ═══════════════════════════════════════════════════════════════════════════════
#  1. Reset API
# ═══════════════════════════════════════════════════════════════════════════════

class TestResetAPI(unittest.TestCase):

    def test_reset_task1_basic_shapes(self):
        env = make_env()
        obs, cfg = env.reset("task1_single_ward")
        self.assertEqual(obs.day, 0)
        self.assertEqual(obs.task_id, "task1_single_ward")
        self.assertEqual(cfg.episode_length, 30)
        self.assertEqual(len(cfg.units), 1)
        self.assertEqual(len(cfg.medications), 4)

    def test_reset_task2_multi_ward(self):
        env = make_env()
        obs, cfg = env.reset("task2_multi_ward")
        self.assertEqual(cfg.episode_length, 60)
        self.assertEqual(len(cfg.units), 3)
        self.assertEqual(len(cfg.medications), 8)

    def test_reset_task3_surge(self):
        env = make_env()
        obs, cfg = env.reset("task3_surge_crisis")
        self.assertEqual(cfg.episode_length, 90)
        self.assertEqual(len(cfg.units), 4)

    def test_reset_invalid_task_raises(self):
        env = make_env()
        with self.assertRaises(ValueError):
            env.reset("nonexistent_task_xyz")

    def test_reset_with_seed_is_reproducible(self):
        env = make_env()
        obs1, _ = env.reset("task1_single_ward", seed=99)
        inv1 = dict(obs1.med_inventory)

        obs2, _ = env.reset("task1_single_ward", seed=99)
        inv2 = dict(obs2.med_inventory)

        self.assertEqual(inv1, inv2)

    def test_reset_clears_prior_state(self):
        env = make_env()
        env.reset("task1_single_ward", seed=1)
        for _ in range(5):
            env.step(AgentAction())

        obs, _ = env.reset("task1_single_ward", seed=1)
        self.assertEqual(obs.day, 0)
        self.assertEqual(obs.cumulative_mortality, 0)
        self.assertAlmostEqual(obs.cumulative_cost, 0.0)

    def test_reset_different_seeds_differ(self):
        env = make_env()
        obs_a, _ = env.reset("task2_multi_ward", seed=1)
        obs_b, _ = env.reset("task2_multi_ward", seed=2)
        # Two different seeds should not produce identical patient lists at step 5
        for _ in range(5):
            env.reset("task2_multi_ward", seed=1)
            env.step(AgentAction())
        # Just confirm both reset cleanly
        self.assertIsNotNone(obs_a)
        self.assertIsNotNone(obs_b)


# ═══════════════════════════════════════════════════════════════════════════════
#  2. Step API
# ═══════════════════════════════════════════════════════════════════════════════

class TestStepAPI(unittest.TestCase):

    def setUp(self):
        self.env = make_env()
        self.obs, self.cfg = self.env.reset("task1_single_ward", seed=42)

    def test_step_increments_day(self):
        result = self.env.step(AgentAction())
        self.assertEqual(result.observation.day, 1)

    def test_step_reward_in_range(self):
        result = self.env.step(AgentAction())
        self.assertGreaterEqual(result.reward, -1.0)
        self.assertLessEqual(result.reward, 1.0)

    def test_step_done_after_full_episode(self):
        env = make_env()
        env.reset("task1_single_ward")
        result = None
        for _ in range(30):
            result = env.step(AgentAction())
        self.assertTrue(result.done)

    def test_step_not_done_before_end(self):
        result = self.env.step(AgentAction())
        self.assertFalse(result.done)

    def test_step_after_done_raises(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(30):
            env.step(AgentAction())
        with self.assertRaises(RuntimeError):
            env.step(AgentAction())

    def test_step_with_med_order_creates_pending(self):
        action = AgentAction(
            med_orders=[MedOrderAction(med_id="amoxicillin", quantity=100)]
        )
        result = self.env.step(action)
        pending_ids = {po.med_id for po in result.observation.pending_med_orders}
        self.assertIn("amoxicillin", pending_ids)

    def test_step_with_staff_assign_applies(self):
        action = AgentAction(
            staff_assign=[StaffAssignAction(
                unit_id="gen_ward", doctors=4, nurses=10, techs=3
            )]
        )
        result = self.env.step(action)
        schedules = {s.unit_id: s for s in result.observation.current_schedule}
        self.assertIn("gen_ward", schedules)

    def test_step_rush_order_arrives_day2(self):
        """Rush order (lead_time=1) should arrive by step 2."""
        self.env.step(AgentAction(
            med_orders=[MedOrderAction(med_id="amoxicillin", quantity=50, rush=True)]
        ))
        result2 = self.env.step(AgentAction())
        # At day 2 the delivery has arrived; inventory should reflect it
        stock = result2.observation.med_inventory.get("amoxicillin", 0)
        self.assertGreaterEqual(stock, 0)

    def test_step_empty_action_is_valid(self):
        result = self.env.step(AgentAction())
        self.assertIsNotNone(result.observation)

    def test_step_info_contains_day(self):
        result = self.env.step(AgentAction())
        self.assertIn("day", result.info)
        self.assertEqual(result.info["day"], 1)

    def test_step_info_contains_service_level(self):
        result = self.env.step(AgentAction())
        self.assertIn("service_level", result.info)
        self.assertGreaterEqual(result.info["service_level"], 0.0)
        self.assertLessEqual(result.info["service_level"], 1.0)

    def test_multiple_med_orders_all_pending(self):
        action = AgentAction(med_orders=[
            MedOrderAction(med_id="amoxicillin", quantity=100),
            MedOrderAction(med_id="morphine",    quantity=50),
        ])
        result = self.env.step(action)
        pending_ids = {po.med_id for po in result.observation.pending_med_orders}
        self.assertIn("amoxicillin", pending_ids)
        self.assertIn("morphine", pending_ids)


# ═══════════════════════════════════════════════════════════════════════════════
#  3. State API
# ═══════════════════════════════════════════════════════════════════════════════

class TestStateAPI(unittest.TestCase):

    def test_state_day_zero_before_step(self):
        env = make_env()
        env.reset("task1_single_ward")
        state = env.state()
        self.assertEqual(state.day, 0)

    def test_state_matches_step_observation(self):
        env = make_env()
        env.reset("task1_single_ward")
        result = env.step(AgentAction())
        state = env.state()
        self.assertEqual(state.day, result.observation.day)
        self.assertEqual(state.task_id, result.observation.task_id)

    def test_state_no_side_effects(self):
        env = make_env()
        env.reset("task1_single_ward")
        env.step(AgentAction())
        env.state()
        env.state()  # Call twice – day should stay at 1
        state = env.state()
        self.assertEqual(state.day, 1)


# ═══════════════════════════════════════════════════════════════════════════════
#  4. Score API
# ═══════════════════════════════════════════════════════════════════════════════

class TestScoreAPI(unittest.TestCase):

    def test_score_before_done_raises(self):
        env = make_env()
        env.reset("task1_single_ward")
        env.step(AgentAction())
        with self.assertRaises(RuntimeError):
            env.score()

    def test_score_range(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(30):
            env.step(AgentAction())
        s = env.score()
        self.assertGreaterEqual(s.score, 0.0)
        self.assertLessEqual(s.score, 1.5)  # can exceed 1.0 with terminal bonus before clip

    def test_score_grade_valid(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(30):
            env.step(AgentAction())
        s = env.score()
        self.assertIn(s.grade, ("A", "B", "C", "D", "F"))

    def test_score_task_id_correct(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(30):
            env.step(AgentAction())
        s = env.score()
        self.assertEqual(s.task_id, "task1_single_ward")

    def test_score_breakdown_has_all_keys(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(30):
            env.step(AgentAction())
        s = env.score()
        for key in ("service_level", "patient_safety", "cost_efficiency", "bed_utilization"):
            self.assertIn(key, s.breakdown)

    def test_score_task2_has_transfer_timing(self):
        env = make_env()
        env.reset("task2_multi_ward")
        for _ in range(60):
            env.step(AgentAction())
        s = env.score()
        self.assertIn("transfer_timing", s.breakdown)


# ═══════════════════════════════════════════════════════════════════════════════
#  5. Observation schema correctness
# ═══════════════════════════════════════════════════════════════════════════════

class TestObservationSchema(unittest.TestCase):

    def test_all_observation_fields_present(self):
        env = make_env()
        obs, _ = env.reset("task1_single_ward")
        for attr in [
            "day", "episode_length", "task_id", "patients", "bed_allocations",
            "med_inventory", "pending_med_orders", "current_schedule", "staff_pools",
            "recent_metrics", "cumulative_cost", "cumulative_revenue",
            "cumulative_profit", "cumulative_mortality", "cumulative_stockouts",
            "expected_admissions",
        ]:
            self.assertTrue(hasattr(obs, attr), f"Missing field: {attr}")

    def test_med_inventory_non_negative_throughout(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(30):
            result = env.step(AgentAction())
            for qty in result.observation.med_inventory.values():
                self.assertGreaterEqual(qty, 0)

    def test_cumulative_cost_monotonically_increases(self):
        env = make_env()
        env.reset("task1_single_ward")
        prev_cost = 0.0
        for _ in range(10):
            result = env.step(AgentAction())
            self.assertGreaterEqual(result.observation.cumulative_cost, prev_cost - 0.01)
            prev_cost = result.observation.cumulative_cost

    def test_recent_metrics_max_7(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(15):
            result = env.step(AgentAction())
        self.assertLessEqual(len(result.observation.recent_metrics), 7)

    def test_bed_allocations_all_units_present(self):
        env = make_env()
        obs, cfg = env.reset("task2_multi_ward")
        unit_ids = {u.id for u in cfg.units}
        alloc_ids = {ba.unit_id for ba in obs.bed_allocations}
        self.assertEqual(unit_ids, alloc_ids)

    def test_expected_admissions_populated_after_reset(self):
        env = make_env()
        obs, _ = env.reset("task1_single_ward")
        self.assertIsInstance(obs.expected_admissions, list)

    def test_model_dump_returns_dict(self):
        env = make_env()
        obs, cfg = env.reset("task1_single_ward")
        d = obs.model_dump()
        self.assertIsInstance(d, dict)
        self.assertIn("day", d)
        self.assertIn("patients", d)


# ═══════════════════════════════════════════════════════════════════════════════
#  6. Reward properties
# ═══════════════════════════════════════════════════════════════════════════════

class TestReward(unittest.TestCase):

    def test_reward_clipped_to_minus1_plus1(self):
        env = make_env()
        env.reset("task1_single_ward")
        for _ in range(10):
            result = env.step(AgentAction())
            self.assertGreaterEqual(result.reward, -1.0)
            self.assertLessEqual(result.reward, 1.0)

    def test_full_episode_cumulative_reward_is_finite(self):
        env = make_env()
        env.reset("task1_single_ward")
        total = 0.0
        for _ in range(30):
            result = env.step(AgentAction())
            total += result.reward
        self.assertFalse(total != total)  # NaN check

    def test_stocked_agent_reward_not_worse_than_empty(self):
        """Agent that pre-orders meds should not get significantly lower reward."""
        # No orders
        env1 = make_env()
        env1.reset("task1_single_ward", seed=5)
        r_empty = sum(env1.step(AgentAction()).reward for _ in range(5))

        # With generous stock orders
        env2 = make_env()
        env2.reset("task1_single_ward", seed=5)
        r_stocked = 0.0
        for _ in range(5):
            r_stocked += env2.step(AgentAction(
                med_orders=[
                    MedOrderAction(med_id="amoxicillin", quantity=300),
                    MedOrderAction(med_id="morphine",    quantity=150),
                ]
            )).reward
        # Stocked agent should not be dramatically worse than empty
        self.assertGreater(r_stocked, r_empty - 3.0)


# ═══════════════════════════════════════════════════════════════════════════════
#  7. Graders
# ═══════════════════════════════════════════════════════════════════════════════

class TestGraders(unittest.TestCase):

    def _make_metrics(self, n, service_level=1.0, mortality=0, cost=10_000, revenue=20_000, util=0.80):
        from environment.models import DailyMetrics
        return [
            DailyMetrics(
                day=i, admissions=3, discharges=3, transfers=0,
                mortality_events=mortality, stockout_incidents=0,
                understaffed_shifts=0, bed_utilization=util,
                service_level=service_level,
                total_cost=cost, total_revenue=revenue,
                profit=revenue - cost,
            )
            for i in range(1, n + 1)
        ]

    def test_perfect_task1_gets_high_score(self):
        from environment.graders.graders import Task1Grader
        metrics = self._make_metrics(30, service_level=1.0, mortality=0,
                                     cost=8_000, revenue=18_000)
        s = Task1Grader().grade(metrics, total_patients=90)
        self.assertGreaterEqual(s.score, 0.80)
        self.assertIn(s.grade, ("A", "B"))

    def test_zero_service_level_gives_low_score(self):
        from environment.graders.graders import Task1Grader
        metrics = self._make_metrics(30, service_level=0.0, mortality=2,
                                     cost=50_000, revenue=5_000, util=1.0)
        s = Task1Grader().grade(metrics, total_patients=60)
        self.assertLess(s.score, 0.45)

    def test_score_in_0_to_1(self):
        from environment.graders.graders import Task1Grader, Task2Grader, Task3Grader
        metrics30 = self._make_metrics(30)
        metrics60 = self._make_metrics(60)
        metrics90 = self._make_metrics(90)
        for Grader, metrics in [
            (Task1Grader, metrics30),
            (Task2Grader, metrics60),
            (Task3Grader, metrics90),
        ]:
            s = Grader().grade(metrics, total_patients=50)
            self.assertGreaterEqual(s.score, 0.0)
            self.assertLessEqual(s.score, 1.0)

    def test_grade_episode_dispatch(self):
        from environment.graders.graders import grade_episode
        metrics = self._make_metrics(30)
        s = grade_episode("task1_single_ward", metrics, total_patients=90)
        self.assertEqual(s.task_id, "task1_single_ward")
        self.assertIn(s.grade, ("A", "B", "C", "D", "F"))

    def test_unknown_task_raises(self):
        from environment.graders.graders import grade_episode
        metrics = self._make_metrics(30)
        with self.assertRaises(KeyError):
            grade_episode("fake_task", metrics, total_patients=50)


# ═══════════════════════════════════════════════════════════════════════════════
#  8. Baseline agents
# ═══════════════════════════════════════════════════════════════════════════════

class TestBaselineAgents(unittest.TestCase):

    def test_random_agent_produces_valid_action(self):
        env = make_env()
        obs, cfg = env.reset("task1_single_ward")
        agent = RandomAgent(seed=0)
        action = agent.act(obs, cfg)
        self.assertIsInstance(action, AgentAction)

    def test_heuristic_agent_produces_valid_action(self):
        env = make_env()
        obs, cfg = env.reset("task1_single_ward")
        agent = HeuristicAgent()
        action = agent.act(obs, cfg)
        self.assertIsInstance(action, AgentAction)

    def test_greedy_agent_produces_valid_action(self):
        env = make_env()
        obs, cfg = env.reset("task1_single_ward")
        agent = GreedyAgent()
        action = agent.act(obs, cfg)
        self.assertIsInstance(action, AgentAction)

    def test_heuristic_no_duplicate_med_orders(self):
        env = make_env()
        obs, cfg = env.reset("task1_single_ward")
        agent = HeuristicAgent()
        action = agent.act(obs, cfg)
        med_ids = [o.med_id for o in action.med_orders]
        self.assertEqual(len(med_ids), len(set(med_ids)), "Duplicate med orders")

    def test_heuristic_completes_task1(self):
        env = make_env()
        agent = HeuristicAgent()
        obs, cfg = env.reset("task1_single_ward", seed=42)
        steps = 0
        while True:
            action = agent.act(obs, cfg)
            result = env.step(action)
            obs = result.observation
            steps += 1
            if result.done:
                break
        self.assertEqual(steps, 30)
        s = env.score()
        self.assertGreaterEqual(s.score, 0.0)

    def test_heuristic_completes_task2(self):
        env = make_env()
        agent = HeuristicAgent()
        obs, cfg = env.reset("task2_multi_ward", seed=42)
        while True:
            result = env.step(agent.act(obs, cfg))
            obs = result.observation
            if result.done:
                break
        s = env.score()
        self.assertGreaterEqual(s.score, 0.0)
        self.assertLessEqual(s.score, 1.5)

    def test_greedy_completes_task1_above_random(self):
        """Greedy agent should beat random agent on task 1."""
        def run_score(agent_cls, seed=7):
            env = make_env()
            agent = agent_cls() if agent_cls != RandomAgent else agent_cls(seed=0)
            obs, cfg = env.reset("task1_single_ward", seed=seed)
            while True:
                result = env.step(agent.act(obs, cfg))
                obs = result.observation
                if result.done:
                    break
            return env.score().score

        greedy_score = run_score(GreedyAgent)
        random_score = run_score(RandomAgent)
        self.assertGreater(greedy_score, random_score - 0.15)


# ═══════════════════════════════════════════════════════════════════════════════
#  9. Crisis events (Task 3)
# ═══════════════════════════════════════════════════════════════════════════════

class TestCrisisEvents(unittest.TestCase):

    def test_episode_completes_through_all_crises(self):
        env = make_env()
        agent = HeuristicAgent()
        obs, cfg = env.reset("task3_surge_crisis", seed=999)
        steps = 0
        while True:
            result = env.step(agent.act(obs, cfg))
            obs = result.observation
            steps += 1
            if result.done:
                break
        self.assertEqual(steps, 90)

    def test_mass_casualty_event_fires_at_day60(self):
        env = make_env()
        env.reset("task3_surge_crisis", seed=999)
        event_fired = False
        for _ in range(60):
            result = env.step(AgentAction())
            if any("mass" in e.lower() and "casualty" in e.lower() for e in result.info.get("events", [])):
                event_fired = True
        self.assertTrue(event_fired, "Mass casualty event should fire by day 60")

    def test_supply_disruption_fires_at_day15(self):
        env = make_env()
        env.reset("task3_surge_crisis", seed=999)
        disruption_seen = False
        for _ in range(15):
            result = env.step(AgentAction())
            events = result.info.get("events", [])
            if any("disruption" in e.lower() or "supply" in e.lower() for e in events):
                disruption_seen = True
        self.assertTrue(disruption_seen, "Supply disruption should be noted by day 15")

    def test_task3_score_is_valid(self):
        env = make_env()
        agent = HeuristicAgent()
        obs, cfg = env.reset("task3_surge_crisis", seed=999)
        while True:
            result = env.step(agent.act(obs, cfg))
            obs = result.observation
            if result.done:
                break
        s = env.score()
        self.assertGreaterEqual(s.score, 0.0)
        self.assertLessEqual(s.score, 1.5)
        self.assertIn("transfer_timing", s.breakdown)


# ═══════════════════════════════════════════════════════════════════════════════
#  10. Environment utilities
# ═══════════════════════════════════════════════════════════════════════════════

class TestEnvUtilities(unittest.TestCase):

    def test_available_tasks_returns_three(self):
        env = make_env()
        self.assertEqual(len(env.available_tasks()), 3)

    def test_available_tasks_contains_expected_ids(self):
        env = make_env()
        tasks = env.available_tasks()
        self.assertIn("task1_single_ward", tasks)
        self.assertIn("task2_multi_ward", tasks)
        self.assertIn("task3_surge_crisis", tasks)

    def test_task_info_metadata(self):
        env = make_env()
        info = env.task_info("task2_multi_ward")
        self.assertEqual(info["difficulty"], "medium")
        self.assertEqual(info["episode_length"], 60)
        self.assertEqual(info["n_units"], 3)
        self.assertEqual(info["n_medications"], 8)

    def test_task_info_invalid_raises(self):
        env = make_env()
        with self.assertRaises(ValueError):
            env.task_info("fake_task")

    def test_model_dump_is_json_serialisable(self):
        import json
        env = make_env()
        obs, cfg = env.reset("task1_single_ward")
        result = env.step(AgentAction())
        # Should not raise
        json_str = json.dumps(result.observation.model_dump())
        self.assertGreater(len(json_str), 10)

    def test_env_config_model_dump(self):
        env = make_env()
        _, cfg = env.reset("task2_multi_ward")
        d = cfg.model_dump()
        self.assertIn("units", d)
        self.assertIn("medications", d)
        self.assertEqual(d["task_id"], "task2_multi_ward")


# ═════════════════════════════════════════════════════════════════════════════
#  Entry point
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Print summary header
    print("=" * 65)
    print("  Hospital Resource Management OpenEnv – Test Suite")
    print("=" * 65)
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
