"""
Hospital Resource Management OpenEnv – API Server

Exposes the OpenEnv API over HTTP (FastAPI) and a live Gradio dashboard.
Designed for deployment on Hugging Face Spaces.

Endpoints:
  POST /reset         – Start a new episode
  POST /step          – Submit an action, receive observation + reward
  GET  /state         – Current observation
  GET  /score         – Grade the completed episode
  GET  /tasks         – List available tasks with descriptions
  GET  /health        – Health check
  GET  /              – Gradio dashboard (mounted at root)
"""
from __future__ import annotations

import json
import os
import textwrap
from typing import Any, Dict, List, Optional

import gradio as gr
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from environment import HospitalEnv
from environment.models import AgentAction, MedOrderAction, StaffAssignAction
from baseline.agent import HeuristicAgent


# ─────────────────────────────────────────────────────────────────────────────
#  FastAPI app
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Hospital Resource Management OpenEnv",
    description=(
        "A real-world OpenEnv environment simulating hospital operations. "
        "AI agents manage medication inventory, staffing, patient transfers, "
        "and crisis response across ICU, Emergency, General, and Surgical units."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global environment instance (one session per server for demo; use session tokens for prod)
_env = HospitalEnv()
_last_obs: Optional[Any] = None
_last_cfg: Optional[Any] = None
_episode_active = False


# ─── Request / Response models ────────────────────────────────────────────────

class ResetRequest(BaseModel):
    task_id: str = "task1_single_ward"
    seed: Optional[int] = None


class StepRequest(BaseModel):
    action: Dict[str, Any]


class ResetResponse(BaseModel):
    observation: Dict
    config: Dict
    message: str


class StepResponse(BaseModel):
    observation: Dict
    reward: float
    done: bool
    truncated: bool
    info: Dict


# ─── Helper ───────────────────────────────────────────────────────────────────

def _obs_to_dict(obs) -> Dict:
    return obs.model_dump()

def _cfg_to_dict(cfg) -> Dict:
    return cfg.model_dump()


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "version": "1.0.0"}


@app.get("/tasks")
def list_tasks():
    return {
        task_id: _env.task_info(task_id)
        for task_id in _env.available_tasks()
    }


@app.post("/reset", response_model=ResetResponse)
def reset(req: ResetRequest):
    global _last_obs, _last_cfg, _episode_active
    try:
        obs, cfg = _env.reset(task_id=req.task_id, seed=req.seed)
        _last_obs = obs
        _last_cfg = cfg
        _episode_active = True
        return ResetResponse(
            observation=_obs_to_dict(obs),
            config=_cfg_to_dict(cfg),
            message=f"Episode started: {req.task_id}",
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/step", response_model=StepResponse)
def step(req: StepRequest):
    global _last_obs, _episode_active
    if not _episode_active:
        raise HTTPException(status_code=400, detail="No active episode. Call /reset first.")

    # Parse action from dict
    try:
        raw = req.action
        med_orders = [MedOrderAction(**o) for o in raw.get("med_orders", [])]
        staff_assign = [StaffAssignAction(**s) for s in raw.get("staff_assign", [])]
        action = AgentAction(
            med_orders=med_orders,
            staff_assign=staff_assign,
            bed_transfers=[],
            discharges=[],
        )
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Invalid action: {e}")

    try:
        result = _env.step(action)
        _last_obs = result.observation
        if result.done:
            _episode_active = False
        return StepResponse(
            observation=_obs_to_dict(result.observation),
            reward=result.reward,
            done=result.done,
            truncated=result.truncated,
            info=result.info,
        )
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/state")
def state():
    if _last_obs is None:
        raise HTTPException(status_code=400, detail="No active episode.")
    return _obs_to_dict(_last_obs)


@app.get("/score")
def score():
    try:
        s = _env.score()
        return s.model_dump()
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ─────────────────────────────────────────────────────────────────────────────
#  Gradio Dashboard
# ─────────────────────────────────────────────────────────────────────────────

def run_demo_episode(task_id: str, agent_type: str, progress=gr.Progress()):
    """Run a full episode with a selected agent and return a summary."""
    from baseline.agent import RandomAgent, HeuristicAgent, GreedyAgent
    
    agents = {"random": RandomAgent, "heuristic": HeuristicAgent, "greedy": GreedyAgent}
    env = HospitalEnv()
    agent = agents[agent_type]()

    obs, cfg = env.reset(task_id=task_id)
    total_reward = 0.0
    log_lines = [f"🏥 Starting {task_id} with {agent_type} agent ({cfg.episode_length} days)\n"]

    progress(0, desc="Starting episode…")
    for day in range(cfg.episode_length):
        action = agent.act(obs, cfg)
        result = env.step(action)
        total_reward += result.reward
        obs = result.observation

        if (day + 1) % max(1, cfg.episode_length // 10) == 0:
            m = obs.recent_metrics[-1] if obs.recent_metrics else None
            if m:
                log_lines.append(
                    f"Day {day+1:3d}: reward={result.reward:+.3f} | "
                    f"svc={m.service_level:.2%} | "
                    f"patients={len(obs.patients)} | "
                    f"deaths={obs.cumulative_mortality} | "
                    f"cost=${m.total_cost:,.0f}"
                )
            progress((day + 1) / cfg.episode_length, desc=f"Day {day+1}/{cfg.episode_length}")

        if result.done:
            break

    final = env.score()
    log_lines.append(f"\n{'─'*55}")
    log_lines.append(f"📊 FINAL SCORE: {final.score:.4f} ({final.grade})")
    log_lines.append(f"   Total reward:     {total_reward:.3f}")
    log_lines.append(f"   Total patients:   {final.metrics.get('total_patients', 0)}")
    log_lines.append(f"   Mortality:        {final.metrics.get('total_mortality', 0)}")
    log_lines.append(f"   Stockouts:        {final.metrics.get('total_stockouts', 0)}")
    log_lines.append(f"   Avg service:      {final.metrics.get('avg_service_level', 0):.2%}")
    log_lines.append(f"   Avg bed util:     {final.metrics.get('avg_bed_utilization', 0):.2%}")
    log_lines.append(f"   Cost/patient:     ${final.metrics.get('cost_per_patient', 0):,.0f}")
    log_lines.append(f"\n   Sub-scores:")
    for k, v in final.breakdown.items():
        bar = "█" * int(v * 20) + "░" * (20 - int(v * 20))
        log_lines.append(f"   {k:22s} {bar} {v:.3f}")
    log_lines.append(f"\n💡 {final.notes}")

    # Build metrics chart data (for simple text chart)
    chart_data = _build_chart_data(obs)

    return "\n".join(log_lines), chart_data, final.score


def _build_chart_data(obs) -> str:
    if not obs.recent_metrics:
        return "No metrics yet."
    lines = ["Day | SvcLvl | BedUtil | Cost ($k)"]
    lines.append("─" * 40)
    for m in obs.recent_metrics:
        bar_svc = "█" * int(m.service_level * 10)
        lines.append(
            f"{m.day:3d} | {m.service_level:.2f}  | {m.bed_utilization:.2f}    | {m.total_cost/1000:6.1f}k"
        )
    return "\n".join(lines)


def get_task_info(task_id: str) -> str:
    info = _env.task_info(task_id)
    lines = [
        f"**Task:** {info['task_id']}",
        f"**Difficulty:** {info['difficulty'].upper()}",
        f"**Episode length:** {info['episode_length']} days",
        f"**Scenario:** {info['scenario']}",
        f"**Units:** {info['n_units']}",
        f"**Medications tracked:** {info['n_medications']}",
        "",
        f"📋 {info['description']}",
    ]
    return "\n".join(lines)


with gr.Blocks(
    title="Hospital Resource Management OpenEnv",
    theme=gr.themes.Soft(primary_hue="blue"),
    css="""
    .score-box { font-size: 2em; text-align: center; padding: 10px; }
    .log-box { font-family: monospace; font-size: 0.85em; }
    """
) as demo:
    gr.Markdown("""
    # 🏥 Hospital Resource Management OpenEnv

    A real-world OpenEnv environment where AI agents manage a hospital network:
    medication inventory, staffing, patient transfers, and crisis response.

    **API Base URL:** `/` (see `/docs` for full OpenAPI spec)
    """)

    with gr.Tabs():
        # ── Demo tab ──────────────────────────────────────────────────────────
        with gr.TabItem("🎮 Interactive Demo"):
            with gr.Row():
                task_dd = gr.Dropdown(
                    choices=["task1_single_ward", "task2_multi_ward", "task3_surge_crisis"],
                    value="task1_single_ward",
                    label="Task",
                )
                agent_dd = gr.Dropdown(
                    choices=["random", "heuristic", "greedy"],
                    value="heuristic",
                    label="Agent",
                )
                run_btn = gr.Button("▶ Run Episode", variant="primary")

            task_info_box = gr.Markdown(get_task_info("task1_single_ward"))

            with gr.Row():
                score_display = gr.Number(label="Final Score (0–1)", precision=4)

            episode_log = gr.Textbox(
                label="Episode Log",
                lines=30,
                elem_classes=["log-box"],
                show_copy_button=True,
            )
            metrics_table = gr.Textbox(
                label="Recent Daily Metrics",
                lines=12,
                elem_classes=["log-box"],
            )

            task_dd.change(fn=get_task_info, inputs=task_dd, outputs=task_info_box)
            run_btn.click(
                fn=run_demo_episode,
                inputs=[task_dd, agent_dd],
                outputs=[episode_log, metrics_table, score_display],
            )

        # ── API Docs tab ──────────────────────────────────────────────────────
        with gr.TabItem("📖 API Reference"):
            gr.Markdown(textwrap.dedent("""
            ## OpenEnv HTTP API

            ### `POST /reset`
            Start a new episode.
            ```json
            { "task_id": "task1_single_ward", "seed": 42 }
            ```
            Returns `{ observation, config, message }`.

            ---
            ### `POST /step`
            Submit an action and advance one day.
            ```json
            {
              "action": {
                "med_orders": [
                  { "med_id": "amoxicillin", "quantity": 200, "rush": false }
                ],
                "staff_assign": [
                  { "unit_id": "gen_ward", "doctors": 3, "nurses": 8, "techs": 4 }
                ],
                "bed_transfers": [],
                "discharges": []
              }
            }
            ```
            Returns `{ observation, reward, done, truncated, info }`.

            ---
            ### `GET /state`
            Current environment state (same schema as observation).

            ---
            ### `GET /score`
            Final episode score (call after `done == true`).
            Returns `{ task_id, score, grade, metrics, breakdown, notes }`.

            ---
            ### `GET /tasks`
            List all available tasks with descriptions.

            ---
            ### Action Space Summary

            | Field | Type | Description |
            |-------|------|-------------|
            | `med_orders[].med_id` | string | Medication identifier |
            | `med_orders[].quantity` | int ≥ 0 | Units to order |
            | `med_orders[].rush` | bool | Rush delivery (1-day, 2× cost) |
            | `staff_assign[].unit_id` | string | Hospital unit |
            | `staff_assign[].doctors` | int ≥ 0 | Doctors to assign |
            | `staff_assign[].nurses` | int ≥ 0 | Nurses to assign |
            | `staff_assign[].techs` | int ≥ 0 | Technicians to assign |
            | `bed_transfers[].patient_id` | string | Patient to move |
            | `bed_transfers[].to_unit_id` | string | Destination unit |
            | `discharges[].patient_id` | string | Patient to discharge |

            ---
            ### Reward Function
            Dense reward ∈ [−1, +1] per step:
            ```
            r = w_svc  × service_level
              + w_safe × (1 − mortality_rate)
              − w_cost × (day_cost / revenue)
              + w_bed  × bed_utilization_score
            ```
            Terminal bonus: +0.5 if final_score ≥ 0.80

            ---
            ### Score Breakdown (all tasks)

            | Criterion | Weight T1 | Weight T2 | Weight T3 |
            |-----------|-----------|-----------|-----------|
            | Service Level | 35% | 30% | 25% |
            | Patient Safety | 35% | 30% | 35% |
            | Cost Efficiency | 20% | 20% | 15% |
            | Bed Utilization | 10% | 10% | 10% |
            | Transfer Timing | — | 10% | 15% |
            """))

        # ── Environment Info tab ───────────────────────────────────────────────
        with gr.TabItem("🗺️ Environment Overview"):
            gr.Markdown(textwrap.dedent("""
            ## Hospital Resource Management OpenEnv

            ### Real-world scenario
            You manage a hospital network facing the same daily challenges as real
            healthcare administrators:
            - **Medication stockouts** cause patient deterioration and mortality
            - **Understaffing** increases risk for all patients
            - **Bed congestion** forces corridor admissions and delayed care
            - **Supply disruptions** require strategic pre-ordering
            - **Patient acuity shifts** require timely ward transfers

            ### Tasks
            | | Task 1 | Task 2 | Task 3 |
            |-|--------|--------|--------|
            | Difficulty | Easy | Medium | Hard |
            | Duration | 30 days | 60 days | 90 days |
            | Wards | 1 | 3 | 4 |
            | Medications | 4 | 8 | 8 |
            | Crisis events | None | None | 5 events |
            | Scenario | Normal | Normal | Surge (+60%) |

            ### Observation space
            - Patient census per unit (acuity, LOS, med needs, deterioration risk)
            - Medication inventory levels and pending orders
            - Staff assignments and pool availability
            - 7-day KPI history
            - 3-day noisy admission forecast

            ### Baseline scores (seed=42, heuristic agent)
            | Task | Score | Grade |
            |------|-------|-------|
            | task1_single_ward | ~0.62 | C |
            | task2_multi_ward | ~0.55 | D |
            | task3_surge_crisis | ~0.42 | F |

            A well-trained RL agent should achieve 0.80+ on all tasks.
            """))


# ─── Mount Gradio into FastAPI ────────────────────────────────────────────────

app = gr.mount_gradio_app(app, demo, path="/")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 7860))
    uvicorn.run(app, host="0.0.0.0", port=port)
