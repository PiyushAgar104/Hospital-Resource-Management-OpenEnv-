"""
Agent graders for the Hospital Resource Management OpenEnv.

Each grader evaluates a completed episode and returns an EpisodeScore (0.0–1.0).
Graders are composites of several weighted sub-criteria, providing partial
credit so reward signals are dense and informative.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

from environment.models import DailyMetrics, EpisodeScore


# ─── Grade lookup ─────────────────────────────────────────────────────────────

def _letter_grade(score: float) -> str:
    if score >= 0.90:
        return "A"
    if score >= 0.80:
        return "B"
    if score >= 0.70:
        return "C"
    if score >= 0.55:
        return "D"
    return "F"


# ─── Shared sub-score helpers ────────────────────────────────────────────────

def _service_level_score(metrics: List[DailyMetrics], target: float = 0.90) -> float:
    """Mean daily service level, normalised to target."""
    if not metrics:
        return 0.0
    avg = sum(m.service_level for m in metrics) / len(metrics)
    return min(1.0, avg / target)


def _mortality_score(
    metrics: List[DailyMetrics], total_patients: int, threshold: float = 0.02
) -> float:
    """Mortality score: 1.0 if mortality_rate <= threshold, decays above."""
    if total_patients == 0:
        return 1.0
    total_deaths = sum(m.mortality_events for m in metrics)
    rate = total_deaths / max(1, total_patients)
    if rate <= threshold:
        return 1.0
    # Exponential decay above threshold
    excess = rate - threshold
    return max(0.0, math.exp(-15 * excess))


def _cost_efficiency_score(
    metrics: List[DailyMetrics],
    total_patients: int,
    benchmark_cost_per_patient: float,
) -> float:
    """Score based on cost-per-patient vs benchmark."""
    if total_patients == 0:
        return 0.5
    total_cost = sum(m.total_cost for m in metrics)
    cpp = total_cost / total_patients
    ratio = cpp / benchmark_cost_per_patient
    # Best at ratio ≤ 0.8; linear decay to 0 at ratio = 2.0
    if ratio <= 0.8:
        return 1.0
    if ratio >= 2.0:
        return 0.0
    return max(0.0, 1.0 - (ratio - 0.8) / 1.2)


def _bed_utilization_score(
    metrics: List[DailyMetrics], low: float = 0.75, high: float = 0.95
) -> float:
    """Optimal utilisation is in [low, high]; penalise both extremes."""
    if not metrics:
        return 0.0
    avg_util = sum(m.bed_utilization for m in metrics) / len(metrics)
    if low <= avg_util <= high:
        return 1.0
    if avg_util < low:
        return avg_util / low
    # Over-utilisation: risk of corridor patients
    excess = avg_util - high
    return max(0.0, 1.0 - excess / (1.0 - high))


def _stockout_score(metrics: List[DailyMetrics], n_days: int) -> float:
    """Penalise days with any stockout incident."""
    if n_days == 0:
        return 1.0
    days_with_stockout = sum(1 for m in metrics if m.stockout_incidents > 0)
    return max(0.0, 1.0 - days_with_stockout / n_days)


def _staffing_score(metrics: List[DailyMetrics], n_days: int) -> float:
    """Penalise understaffed shifts."""
    if n_days == 0:
        return 1.0
    days_understaffed = sum(1 for m in metrics if m.understaffed_shifts > 0)
    return max(0.0, 1.0 - days_understaffed / n_days)


def _transfer_timing_score(metrics: List[DailyMetrics]) -> float:
    """Reward active transfer management (proxy: positive transfer count)."""
    if not metrics:
        return 0.5
    total_transfers = sum(m.transfers for m in metrics)
    # Expect roughly 1 transfer per 3 days; 0 transfers = 0.3, ≥1/day = 1.0
    total_days = len(metrics)
    rate = total_transfers / total_days
    return min(1.0, 0.3 + 0.7 * min(rate, 1.0))


# ─── Task graders ────────────────────────────────────────────────────────────

class Task1Grader:
    """
    Task 1 (Easy) – Single ward, 30 days.

    Criteria:
      - Service level            35%
      - Patient safety           35%
      - Cost efficiency          20%
      - Bed utilisation          10%
    """

    WEIGHTS = {
        "service_level":   0.35,
        "patient_safety":  0.35,
        "cost_efficiency": 0.20,
        "bed_utilization": 0.10,
    }
    BENCHMARK_CPP = 1_800.0   # cost-per-patient benchmark $

    def grade(
        self,
        metrics: List[DailyMetrics],
        total_patients: int,
        extra: Optional[Dict[str, Any]] = None,
    ) -> EpisodeScore:
        n_days = len(metrics)
        breakdown = {
            "service_level":   _service_level_score(metrics),
            "patient_safety":  _mortality_score(metrics, total_patients, threshold=0.03),
            "cost_efficiency": _cost_efficiency_score(metrics, total_patients, self.BENCHMARK_CPP),
            "bed_utilization": _bed_utilization_score(metrics),
        }
        score = sum(breakdown[k] * v for k, v in self.WEIGHTS.items())
        score = round(max(0.0, min(1.0, score)), 4)

        agg_metrics = {
            "avg_service_level":    round(sum(m.service_level for m in metrics) / max(1, n_days), 3),
            "total_mortality":      sum(m.mortality_events for m in metrics),
            "total_stockouts":      sum(m.stockout_incidents for m in metrics),
            "total_patients":       total_patients,
            "avg_bed_utilization":  round(sum(m.bed_utilization for m in metrics) / max(1, n_days), 3),
            "total_cost":           round(sum(m.total_cost for m in metrics), 2),
            "cost_per_patient":     round(sum(m.total_cost for m in metrics) / max(1, total_patients), 2),
        }

        return EpisodeScore(
            task_id="task1_single_ward",
            score=score,
            grade=_letter_grade(score),
            metrics=agg_metrics,
            breakdown=breakdown,
            notes=self._notes(score, breakdown),
        )

    def _notes(self, score: float, breakdown: Dict) -> str:
        msgs = []
        if breakdown["service_level"] < 0.7:
            msgs.append("High stockout rate – order medications earlier.")
        if breakdown["patient_safety"] < 0.7:
            msgs.append("Mortality elevated – improve staffing and critical med supply.")
        if breakdown["cost_efficiency"] < 0.6:
            msgs.append("Over-budget – avoid unnecessary rush orders and excess inventory.")
        if breakdown["bed_utilization"] < 0.5:
            msgs.append("Low bed utilisation – accept more admissions.")
        if not msgs:
            msgs.append("Good performance across all criteria.")
        return " | ".join(msgs)


class Task2Grader:
    """
    Task 2 (Medium) – Multi-ward, 60 days.

    Criteria:
      - Service level            30%
      - Patient safety           30%
      - Cost efficiency          20%
      - Bed utilisation          10%
      - Transfer timing          10%
    """

    WEIGHTS = {
        "service_level":   0.30,
        "patient_safety":  0.30,
        "cost_efficiency": 0.20,
        "bed_utilization": 0.10,
        "transfer_timing": 0.10,
    }
    BENCHMARK_CPP = 2_500.0

    def grade(
        self,
        metrics: List[DailyMetrics],
        total_patients: int,
        extra: Optional[Dict[str, Any]] = None,
    ) -> EpisodeScore:
        n_days = len(metrics)
        breakdown = {
            "service_level":   _service_level_score(metrics, target=0.88),
            "patient_safety":  _mortality_score(metrics, total_patients, threshold=0.025),
            "cost_efficiency": _cost_efficiency_score(metrics, total_patients, self.BENCHMARK_CPP),
            "bed_utilization": _bed_utilization_score(metrics, low=0.70, high=0.92),
            "transfer_timing": _transfer_timing_score(metrics),
        }
        score = sum(breakdown[k] * v for k, v in self.WEIGHTS.items())
        score = round(max(0.0, min(1.0, score)), 4)

        agg_metrics = {
            "avg_service_level":      round(sum(m.service_level for m in metrics) / max(1, n_days), 3),
            "total_mortality":        sum(m.mortality_events for m in metrics),
            "total_stockouts":        sum(m.stockout_incidents for m in metrics),
            "total_understaffed":     sum(m.understaffed_shifts for m in metrics),
            "total_transfers":        sum(m.transfers for m in metrics),
            "total_patients":         total_patients,
            "avg_bed_utilization":    round(sum(m.bed_utilization for m in metrics) / max(1, n_days), 3),
            "total_cost":             round(sum(m.total_cost for m in metrics), 2),
            "cost_per_patient":       round(sum(m.total_cost for m in metrics) / max(1, total_patients), 2),
        }

        return EpisodeScore(
            task_id="task2_multi_ward",
            score=score,
            grade=_letter_grade(score),
            metrics=agg_metrics,
            breakdown=breakdown,
            notes=self._notes(score, breakdown),
        )

    def _notes(self, score: float, breakdown: Dict) -> str:
        msgs = []
        if breakdown["transfer_timing"] < 0.5:
            msgs.append("Patients not being transferred between units – use transfers to match acuity.")
        if breakdown["patient_safety"] < 0.6:
            msgs.append("High mortality – prioritise ICU admissions and critical meds.")
        if breakdown["service_level"] < 0.65:
            msgs.append("Frequent stockouts across multiple wards – consolidate ordering strategy.")
        if breakdown["cost_efficiency"] < 0.5:
            msgs.append("Costs above benchmark – reduce rush orders and right-size staffing.")
        if not msgs:
            msgs.append("Strong multi-ward coordination.")
        return " | ".join(msgs)


class Task3Grader:
    """
    Task 3 (Hard) – Surge crisis, 90 days.

    Additional criteria:
      - Crisis resilience score based on performance *during* crisis windows
      - Staffing adequacy during strike days (days 30–35)

    Criteria:
      - Service level            25%
      - Patient safety           35%
      - Cost efficiency          15%
      - Bed utilisation          10%
      - Transfer timing          15%
    """

    WEIGHTS = {
        "service_level":   0.25,
        "patient_safety":  0.35,
        "cost_efficiency": 0.15,
        "bed_utilization": 0.10,
        "transfer_timing": 0.15,
    }
    BENCHMARK_CPP = 3_200.0

    # Crisis windows (day indices into episode, 0-based)
    CRISIS_DAYS = set(range(14, 20)) | set(range(29, 36)) | set(range(44, 49)) | set(range(59, 63))

    def grade(
        self,
        metrics: List[DailyMetrics],
        total_patients: int,
        extra: Optional[Dict[str, Any]] = None,
    ) -> EpisodeScore:
        n_days = len(metrics)
        crisis_metrics = [m for m in metrics if (m.day - 1) in self.CRISIS_DAYS]
        normal_metrics = [m for m in metrics if (m.day - 1) not in self.CRISIS_DAYS]

        # Base sub-scores
        breakdown = {
            "service_level":   _service_level_score(metrics, target=0.85),
            "patient_safety":  _mortality_score(metrics, total_patients, threshold=0.02),
            "cost_efficiency": _cost_efficiency_score(metrics, total_patients, self.BENCHMARK_CPP),
            "bed_utilization": _bed_utilization_score(metrics, low=0.65, high=0.95),
            "transfer_timing": _transfer_timing_score(metrics),
        }

        # Crisis resilience bonus / penalty applied inside patient_safety
        if crisis_metrics:
            crisis_mortality = sum(m.mortality_events for m in crisis_metrics)
            crisis_patients_approx = max(1, int(total_patients * len(crisis_metrics) / max(1, n_days)))
            crisis_safety = _mortality_score(crisis_metrics, crisis_patients_approx, threshold=0.04)
            # Blend: 60% full-episode, 40% crisis window
            breakdown["patient_safety"] = 0.60 * breakdown["patient_safety"] + 0.40 * crisis_safety

        score = sum(breakdown[k] * v for k, v in self.WEIGHTS.items())
        score = round(max(0.0, min(1.0, score)), 4)

        agg_metrics = {
            "avg_service_level":       round(sum(m.service_level for m in metrics) / max(1, n_days), 3),
            "crisis_service_level":    round(sum(m.service_level for m in crisis_metrics) / max(1, len(crisis_metrics)), 3) if crisis_metrics else None,
            "total_mortality":         sum(m.mortality_events for m in metrics),
            "crisis_mortality":        sum(m.mortality_events for m in crisis_metrics),
            "total_stockouts":         sum(m.stockout_incidents for m in metrics),
            "total_understaffed":      sum(m.understaffed_shifts for m in metrics),
            "total_transfers":         sum(m.transfers for m in metrics),
            "total_patients":          total_patients,
            "avg_bed_utilization":     round(sum(m.bed_utilization for m in metrics) / max(1, n_days), 3),
            "total_cost":              round(sum(m.total_cost for m in metrics), 2),
            "cost_per_patient":        round(sum(m.total_cost for m in metrics) / max(1, total_patients), 2),
        }

        return EpisodeScore(
            task_id="task3_surge_crisis",
            score=score,
            grade=_letter_grade(score),
            metrics=agg_metrics,
            breakdown=breakdown,
            notes=self._notes(score, breakdown, crisis_metrics),
        )

    def _notes(self, score: float, breakdown: Dict, crisis_metrics: List) -> str:
        msgs = []
        if breakdown["patient_safety"] < 0.5:
            msgs.append("Critical: mortality too high during crisis events – stockpile critical meds before disruptions.")
        if breakdown["service_level"] < 0.5:
            msgs.append("Service level collapse during surge – pre-order aggressively.")
        if breakdown["cost_efficiency"] < 0.4:
            msgs.append("Over-budget – balance rush orders with standard lead times.")
        if breakdown["transfer_timing"] < 0.5:
            msgs.append("Poor patient flow – ICU should be reserved for CRITICAL acuity only.")
        if score >= 0.75:
            msgs.append("Effective crisis management demonstrated.")
        elif not msgs:
            msgs.append("Partial crisis response – study crisis window metrics for improvement areas.")
        return " | ".join(msgs)


# ─── Registry ────────────────────────────────────────────────────────────────

GRADERS = {
    "task1_single_ward":  Task1Grader(),
    "task2_multi_ward":   Task2Grader(),
    "task3_surge_crisis": Task3Grader(),
}


def grade_episode(
    task_id: str,
    metrics: List[DailyMetrics],
    total_patients: int,
    extra: Optional[Dict[str, Any]] = None,
) -> EpisodeScore:
    """Grade a completed episode. Raises KeyError for unknown task_id."""
    grader = GRADERS[task_id]
    return grader.grade(metrics, total_patients, extra)
