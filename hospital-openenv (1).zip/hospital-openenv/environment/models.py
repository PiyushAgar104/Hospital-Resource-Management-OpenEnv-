"""
Typed models for the Hospital Resource Management OpenEnv.
Uses stdlib dataclasses for zero-dependency portability.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# ─────────────────────────────────────────────
#  Enums
# ─────────────────────────────────────────────

class PatientAcuity(str, Enum):
    LOW      = "low"
    MEDIUM   = "medium"
    HIGH     = "high"
    CRITICAL = "critical"


class UnitType(str, Enum):
    ICU       = "icu"
    GENERAL   = "general"
    EMERGENCY = "emergency"
    SURGERY   = "surgery"


class StaffRole(str, Enum):
    DOCTOR = "doctor"
    NURSE  = "nurse"
    TECH   = "technician"


class MedCategory(str, Enum):
    ANTIBIOTIC    = "antibiotic"
    ANALGESIC     = "analgesic"
    CARDIAC       = "cardiac"
    SEDATIVE      = "sedative"
    BLOOD_PRODUCT = "blood_product"


# ─────────────────────────────────────────────
#  Helper: recursive dict serialisation
# ─────────────────────────────────────────────

def _to_dict(obj: Any) -> Any:
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, list):
        return [_to_dict(i) for i in obj]
    if isinstance(obj, dict):
        return {k: _to_dict(v) for k, v in obj.items()}
    if hasattr(obj, "__dataclass_fields__"):
        return {k: _to_dict(getattr(obj, k)) for k in obj.__dataclass_fields__}
    return obj


# ─────────────────────────────────────────────
#  Static config models
# ─────────────────────────────────────────────

@dataclass
class HospitalUnit:
    id: str
    name: str
    unit_type: UnitType
    bed_capacity: int
    min_nurse_ratio: float
    min_doctor_ratio: float

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class Medication:
    id: str
    name: str
    category: MedCategory
    unit_cost: float
    holding_cost_per_day: float
    stockout_penalty: float
    lead_time_days: int
    shelf_life_days: int
    max_order_qty: int
    critical: bool = False

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class StaffPool:
    role: StaffRole
    available: int
    daily_cost: float
    overtime_cost: float

    def model_dump(self) -> Dict:
        return _to_dict(self)


# ─────────────────────────────────────────────
#  Dynamic state models
# ─────────────────────────────────────────────

@dataclass
class Patient:
    acuity: PatientAcuity
    unit_id: str
    admission_day: int
    expected_los: int
    meds_needed: Dict[str, int]
    deterioration_risk: float
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class PendingMedOrder:
    med_id: str
    quantity: int
    arrival_day: int
    cost: float
    rush: bool = False
    order_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class StaffSchedule:
    unit_id: str
    day: int
    doctors: int
    nurses: int
    techs: int

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class BedAllocation:
    unit_id: str
    occupied: int
    reserved: int
    available: int

    def model_dump(self) -> Dict:
        return _to_dict(self)


# ─────────────────────────────────────────────
#  Action models
# ─────────────────────────────────────────────

@dataclass
class MedOrderAction:
    med_id: str
    quantity: int = 0
    rush: bool = False

    def __post_init__(self):
        if self.quantity < 0:
            raise ValueError("quantity must be >= 0")

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class StaffAssignAction:
    unit_id: str
    doctors: int = 0
    nurses: int = 0
    techs: int = 0

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class BedTransferAction:
    patient_id: str
    to_unit_id: str

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class DischargeAction:
    patient_id: str

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class AgentAction:
    med_orders: List[MedOrderAction] = field(default_factory=list)
    staff_assign: List[StaffAssignAction] = field(default_factory=list)
    bed_transfers: List[BedTransferAction] = field(default_factory=list)
    discharges: List[DischargeAction] = field(default_factory=list)

    def model_dump(self) -> Dict:
        return _to_dict(self)


# ─────────────────────────────────────────────
#  Observation / result models
# ─────────────────────────────────────────────

@dataclass
class DailyMetrics:
    day: int
    admissions: int
    discharges: int
    transfers: int
    mortality_events: int
    stockout_incidents: int
    understaffed_shifts: int
    bed_utilization: float
    service_level: float
    total_cost: float
    total_revenue: float
    profit: float

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class Observation:
    day: int
    episode_length: int
    task_id: str
    patients: List[Patient]
    bed_allocations: List[BedAllocation]
    med_inventory: Dict[str, int]
    pending_med_orders: List[PendingMedOrder]
    current_schedule: List[StaffSchedule]
    staff_pools: List[StaffPool]
    recent_metrics: List[DailyMetrics]
    cumulative_cost: float
    cumulative_revenue: float
    cumulative_profit: float
    cumulative_mortality: int
    cumulative_stockouts: int
    expected_admissions: List[Dict[str, Any]]

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class StepResult:
    observation: Observation
    reward: float
    done: bool
    truncated: bool
    info: Dict[str, Any]

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class EpisodeScore:
    task_id: str
    score: float
    grade: str
    metrics: Dict[str, Any]
    breakdown: Dict[str, float]
    notes: str

    def model_dump(self) -> Dict:
        return _to_dict(self)


@dataclass
class EnvConfig:
    task_id: str
    episode_length: int
    units: List[HospitalUnit]
    medications: List[Medication]
    staff_pools: List[StaffPool]
    action_space_description: Dict[str, Any]
    observation_space_description: Dict[str, Any]
    reward_description: str

    def model_dump(self) -> Dict:
        return _to_dict(self)
