#!/usr/bin/env python3
"""
Baseline evaluation script for Hospital Resource Management OpenEnv.

Runs all three agents × all three tasks and prints a reproducible score table.

Usage:
    python -m baseline.run_baseline
    python -m baseline.run_baseline --task task1_single_ward --agent heuristic
    python -m baseline.run_baseline --seeds 3 --verbose
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Allow running from project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from environment import HospitalEnv, AgentAction
from baseline.agent import GreedyAgent, HeuristicAgent, RandomAgent


AGENTS = {
    "random":    lambda: RandomAgent(seed=7),
    "heuristic": HeuristicAgent,
    "greedy":    GreedyAgent,
}

TASKS = ["task1_single_ward", "task2_multi_ward", "task3_surge_crisis"]


def run_episode(
    task_id: str,
    agent_name: str,
    seed: int = 42,
    verbose: bool = False,
) -> Dict:
    env = HospitalEnv()
    agent_cls = AGENTS[agent_name]
    agent = agent_cls()

    obs, cfg = env.reset(task_id=task_id, seed=seed)
    total_reward = 0.0
    steps = 0
    start_time = time.time()

    while True:
        action = agent.act(obs, cfg)
        result = env.step(action)
        total_reward += result.reward
        steps += 1
        obs = result.observation

        if verbose and steps % 10 == 0:
            metrics = obs.recent_metrics[-1] if obs.recent_metrics else None
            svc = f"{metrics.service_level:.3f}" if metrics else "N/A"
            print(
                f"  Day {steps:3d}/{cfg.episode_length} | "
                f"Reward: {result.reward:+.3f} | "
                f"SvcLvl: {svc} | "
                f"Patients: {len(obs.patients):3d} | "
                f"Deaths: {obs.cumulative_mortality}"
            )

        if result.done:
            break

    final_score = env.score()
    elapsed = time.time() - start_time

    return {
        "task_id":      task_id,
        "agent":        agent_name,
        "seed":         seed,
        "score":        final_score.score,
        "grade":        final_score.grade,
        "total_reward": round(total_reward, 3),
        "steps":        steps,
        "elapsed_s":    round(elapsed, 2),
        "metrics":      final_score.metrics,
        "breakdown":    final_score.breakdown,
        "notes":        final_score.notes,
    }


def run_multi_seed(
    task_id: str,
    agent_name: str,
    seeds: List[int],
    verbose: bool = False,
) -> Dict:
    results = []
    for seed in seeds:
        r = run_episode(task_id, agent_name, seed=seed, verbose=verbose)
        results.append(r)

    scores = [r["score"] for r in results]
    avg = sum(scores) / len(scores)
    mn  = min(scores)
    mx  = max(scores)
    std = (sum((s - avg) ** 2 for s in scores) / len(scores)) ** 0.5

    return {
        "task_id":    task_id,
        "agent":      agent_name,
        "seeds":      seeds,
        "mean_score": round(avg, 4),
        "min_score":  round(mn, 4),
        "max_score":  round(mx, 4),
        "std_score":  round(std, 4),
        "runs":       results,
    }


def print_table(rows: List[Dict]) -> None:
    col_widths = [24, 12, 10, 10, 10, 6]
    headers = ["Task", "Agent", "Mean", "Min", "Max", "Grade"]
    sep = "─" * sum(col_widths + [3 * len(col_widths)])

    def row_str(vals):
        return " │ ".join(str(v).ljust(w) for v, w in zip(vals, col_widths))

    print(sep)
    print(row_str(headers))
    print(sep)
    for r in rows:
        grade = "A" if r["mean_score"] >= 0.90 else "B" if r["mean_score"] >= 0.80 else "C" if r["mean_score"] >= 0.70 else "D" if r["mean_score"] >= 0.55 else "F"
        print(row_str([
            r["task_id"],
            r["agent"],
            f"{r['mean_score']:.4f}",
            f"{r['min_score']:.4f}",
            f"{r['max_score']:.4f}",
            grade,
        ]))
    print(sep)


def main() -> None:
    parser = argparse.ArgumentParser(description="Hospital OpenEnv Baseline Evaluation")
    parser.add_argument("--task",    choices=TASKS + ["all"],   default="all")
    parser.add_argument("--agent",   choices=list(AGENTS) + ["all"], default="all")
    parser.add_argument("--seeds",   type=int, default=1, help="Number of random seeds")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--json",    action="store_true", help="Output JSON results")
    args = parser.parse_args()

    tasks_to_run = TASKS if args.task == "all" else [args.task]
    agents_to_run = list(AGENTS.keys()) if args.agent == "all" else [args.agent]
    seed_list = list(range(42, 42 + args.seeds))

    print(f"\n{'='*70}")
    print("  Hospital Resource Management OpenEnv – Baseline Evaluation")
    print(f"  Tasks: {tasks_to_run}")
    print(f"  Agents: {agents_to_run}")
    print(f"  Seeds: {seed_list}")
    print(f"{'='*70}\n")

    all_results = []
    for task_id in tasks_to_run:
        for agent_name in agents_to_run:
            print(f"Running {agent_name} on {task_id} (seeds={seed_list}) …", flush=True)
            result = run_multi_seed(task_id, agent_name, seed_list, verbose=args.verbose)
            all_results.append(result)
            print(
                f"  → mean={result['mean_score']:.4f}  "
                f"[{result['min_score']:.4f}, {result['max_score']:.4f}]  "
                f"std={result['std_score']:.4f}"
            )
            if args.verbose:
                run0 = result["runs"][0]
                print(f"     notes: {run0['notes']}")
                print(f"     breakdown: {run0['breakdown']}")

    print("\n")
    print_table(all_results)

    if args.json:
        out_path = Path("baseline_results.json")
        with open(out_path, "w") as f:
            json.dump(all_results, f, indent=2)
        print(f"\nResults saved to {out_path}")

    # Human-readable expected scores (reference)
    print("\n📊 Reference Baseline Scores (seed=42, 1 run):")
    print("  task1_single_ward  | random:    ~0.35  | heuristic: ~0.62  | greedy: ~0.71")
    print("  task2_multi_ward   | random:    ~0.28  | heuristic: ~0.55  | greedy: ~0.64")
    print("  task3_surge_crisis | random:    ~0.18  | heuristic: ~0.42  | greedy: ~0.53")
    print("\n  ✅ Environment is working correctly if scores are within ±0.10 of reference.\n")


if __name__ == "__main__":
    main()
