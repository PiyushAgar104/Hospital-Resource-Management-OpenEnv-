# Reward Design

This document explains the reasoning behind every aspect of the reward function.

---

## Design goals

1. **Dense** — the agent receives a meaningful signal every step, not just at episode end.
2. **Multi-objective** — healthcare is inherently multi-objective; a single metric (e.g. cost) would produce pathological agents that harm patients.
3. **Partial credit** — near-optimal behaviour should score close to optimal; there should be no cliffs.
4. **Bounded** — clipping to `[−1, +1]` makes it compatible with standard RL algorithms without tuning reward scale.
5. **Task-aware** — harder tasks shift weight toward safety and away from cost, reflecting real clinical priorities during crises.

---

## Step reward

```
r_t = w_svc  × service_level_t
    + w_safe × safety_t
    − w_cost × cost_fraction_t
    + w_bed  × bed_util_t
```

then `r_t = clip(r_t, −1.0, +1.0)`.

### Service level component

```
service_level_t = fulfilled_med_units_t / demanded_med_units_t  ∈ [0, 1]
```

A stockout of any medication reduces this. Critical medications (vancomycin, morphine, midazolam, blood products) drive higher demand and thus higher penalty when stocked out.

### Safety component

```
safety_t = 1 − min(1.0, mortality_events_t / max(1, census_t) × 20)
```

The `× 20` amplifier means even a single death in a 20-patient ward halves the safety score for that day. This is intentional — mortality is a catastrophic outcome.

### Cost component

```
cost_fraction_t = min(1.0, day_cost_t / max(1, revenue_t))
```

Revenue is patient-day reimbursement (flat $350/patient/day). The cost component is negative — spending more than revenue earns a negative contribution. Rush orders, overstaffing, and stockout penalties all increase cost.

### Bed utilisation component

```
             ⎧ util / 0.75          if util < 0.75   (underuse)
bed_util_t = ⎨ 1.0                  if 0.75 ≤ util ≤ 0.95
             ⎩ 1 − (util−0.95)/0.05 if util > 0.95   (overcrowding)
```

The optimal band (75–95%) reflects real hospital targets. Below 75% represents wasted capacity; above 95% represents corridor admissions and safety risk.

---

## Terminal bonus

```
r_terminal += 0.5  if  final_score ≥ 0.80
```

This bonus is added to the last step's reward. It provides a strong incentive for sustained high performance across the full episode, discouraging agents that sacrifice the last few days to boost earlier rewards.

---

## Episode grading (separate from step reward)

The episode score `∈ [0.0, 1.0]` is computed by the task-specific grader at episode end. It is not the sum of step rewards — it is an independent evaluation:

| Sub-score | Formula |
|-----------|---------|
| `service_level` | `mean(daily_service_level) / target_service_level` |
| `patient_safety` | `exp(−15 × max(0, mortality_rate − threshold))` |
| `cost_efficiency` | `1 − max(0, (cpp/benchmark − 0.8) / 1.2)` |
| `bed_utilization` | piecewise linear, optimal band per task |
| `transfer_timing` | `0.3 + 0.7 × min(transfers_per_day, 1.0)` |

Task 3 also applies a **crisis resilience blend**: patient safety score = 60% full-episode + 40% crisis-window-only performance.

---

## Component weights by task

| Component | Task 1 | Task 2 | Task 3 | Rationale |
|-----------|--------|--------|--------|-----------|
| Service level | 35% | 30% | 25% | Harder tasks have more crisis days where full service is impossible |
| Patient safety | 35% | 30% | 35% | Mortality is the most critical outcome; weighted up in surge |
| Cost efficiency | 20% | 20% | 15% | During crises, spending more to save lives is correct |
| Bed utilisation | 10% | 10% | 10% | Always relevant, always a small weight |
| Transfer timing | — | 10% | 15% | Multi-ward coordination becomes critical in harder tasks |

---

## Why not use a single KPI?

| KPI only | Pathological behaviour |
|----------|----------------------|
| Cost only | Agent discharges everyone immediately, stops ordering meds |
| Service level only | Agent orders 10× required stock; huge holding costs |
| Mortality only | Agent keeps every patient in ICU regardless of acuity |
| Bed util only | Agent refuses to discharge anyone |

The weighted combination forces the agent to balance all of these, just as a real hospital administrator must.
