# Quickstart Guide

Get from zero to a running agent in under 5 minutes.

---

## Installation

```bash
git clone https://github.com/your-org/hospital-openenv.git
cd hospital-openenv

# No pip install needed for core environment — stdlib + numpy only
python -m unittest tests.test_env -v   # all 60 tests should pass
```

---

## Run your first episode (5 lines)

```python
from environment import HospitalEnv, AgentAction
from baseline.agent import HeuristicAgent

env   = HospitalEnv()
agent = HeuristicAgent()
obs, cfg = env.reset("task1_single_ward", seed=42)

while True:
    result = env.step(agent.act(obs, cfg))
    obs = result.observation
    if result.done:
        break

score = env.score()
print(f"Score: {score.score:.4f}  Grade: {score.grade}")
# → Score: 0.9693  Grade: A
```

---

## Understand the observation

```python
obs, cfg = env.reset("task2_multi_ward")

print(f"Day {obs.day} of {obs.episode_length}")
print(f"Patients: {len(obs.patients)}")
print(f"Medication stock: {obs.med_inventory}")
print(f"Pending deliveries: {len(obs.pending_med_orders)}")
print(f"3-day forecast (first 3): {obs.expected_admissions[:3]}")

# Each patient has:
p = obs.patients[0]
print(f"  Patient {p.id}: {p.acuity.value} acuity, unit={p.unit_id}")
print(f"  Needs: {p.meds_needed} units/day")
print(f"  Deterioration risk: {p.deterioration_risk:.1%}")
```

---

## Take a specific action

```python
from environment.models import (
    AgentAction, MedOrderAction, StaffAssignAction,
    BedTransferAction, DischargeAction
)

action = AgentAction(
    # Order medications (standard = 2-day lead time, rush = 1 day × 2× cost)
    med_orders=[
        MedOrderAction(med_id="vancomycin", quantity=100, rush=False),
        MedOrderAction(med_id="morphine",   quantity=80,  rush=True),
    ],

    # Assign staff to units
    staff_assign=[
        StaffAssignAction(unit_id="icu",      doctors=4, nurses=12, techs=3),
        StaffAssignAction(unit_id="gen_ward", doctors=3, nurses=8,  techs=2),
    ],

    # Transfer CRITICAL patient to ICU
    bed_transfers=[
        BedTransferAction(patient_id="a3f9b2c1", to_unit_id="icu"),
    ],

    # Early-discharge a stable LOW-acuity patient
    discharges=[
        DischargeAction(patient_id="7d2e1a4f"),
    ],
)

result = env.step(action)
print(f"Reward: {result.reward:+.3f}")
print(f"Service level: {result.info['service_level']:.1%}")
print(f"Cost today:    ${result.info['day_cost']:,.0f}")
print(f"Crisis events: {result.info['events']}")
```

---

## Write your own agent

```python
from environment.models import (
    AgentAction, MedOrderAction, StaffAssignAction,
    Observation, EnvConfig
)
import math

class MyAgent:
    def act(self, obs: Observation, cfg: EnvConfig) -> AgentAction:
        med_catalog = {m.id: m for m in cfg.medications}
        unit_catalog = {u.id: u for u in cfg.units}

        # ── Order medications ──────────────────────────────────────────
        orders = []
        for med_id, med in med_catalog.items():
            # Estimate daily demand from current patients
            daily_demand = sum(
                p.meds_needed.get(med_id, 0) for p in obs.patients
            )
            if daily_demand == 0:
                daily_demand = 1  # safety buffer

            on_hand = obs.med_inventory.get(med_id, 0)
            on_order = sum(
                po.quantity for po in obs.pending_med_orders
                if po.med_id == med_id
            )
            coverage_days = (on_hand + on_order) / daily_demand

            if coverage_days < med.lead_time_days + 3:  # reorder point
                order_qty = daily_demand * 7 - (on_hand + on_order)
                rush = on_hand < daily_demand * 2  # critically low
                if order_qty > 0:
                    orders.append(MedOrderAction(
                        med_id=med_id,
                        quantity=min(int(order_qty), med.max_order_qty),
                        rush=rush,
                    ))

        # ── Assign staff ───────────────────────────────────────────────
        staffing = []
        for unit_id, unit in unit_catalog.items():
            census = sum(1 for p in obs.patients if p.unit_id == unit_id)
            req_nurses  = math.ceil(census * unit.min_nurse_ratio  * 1.2)
            req_doctors = math.ceil(census * unit.min_doctor_ratio * 1.2)
            staffing.append(StaffAssignAction(
                unit_id=unit_id,
                doctors=req_doctors,
                nurses=req_nurses,
                techs=max(1, census // 10),
            ))

        return AgentAction(med_orders=orders, staff_assign=staffing)


# Run it
from environment import HospitalEnv
env = HospitalEnv()
agent = MyAgent()
obs, cfg = env.reset("task2_multi_ward", seed=42)

total_reward = 0.0
while True:
    result = env.step(agent.act(obs, cfg))
    obs = result.observation
    total_reward += result.reward
    if result.done:
        break

score = env.score()
print(f"Score: {score.score:.4f} ({score.grade})")
print(f"Total reward: {total_reward:.3f}")
print(f"Breakdown: {score.breakdown}")
```

---

## Run all three tasks and compare agents

```bash
python -m baseline.run_baseline --seeds 3 --verbose --json
```

Output:
```
Task                     │ Agent        │ Mean   │ Min    │ Max    │ Grade
─────────────────────────────────────────────────────────────────────────
task1_single_ward        │ random       │ 0.9476 │ ...    │ ...    │ A
task1_single_ward        │ heuristic    │ 0.9693 │ ...    │ ...    │ A
task2_multi_ward         │ heuristic    │ 0.8070 │ ...    │ ...    │ B
task3_surge_crisis       │ heuristic    │ 0.8489 │ ...    │ ...    │ B
```

---

## Start the local server and dashboard

```bash
python server.py
# Open http://localhost:7860  — interactive dashboard
# Open http://localhost:7860/health  — API health check
```

Use the dashboard to run any agent × task combination interactively and inspect the daily performance chart.

---

## Deploy to Hugging Face Spaces

```bash
# Create a new Space (Docker SDK) at huggingface.co/new-space
# Then push:
git remote add hf https://huggingface.co/spaces/YOUR-USERNAME/hospital-openenv
git push hf main
```

The Dockerfile handles everything — the Space will build and start automatically.

---

## Next steps

- Read [Architecture Guide](architecture.md) to understand internals
- Read [Reward Design](reward_design.md) to understand the reward function
- Read [Environment Design](environment_design.md) for clinical modelling details
- Check [CONTRIBUTING.md](../CONTRIBUTING.md) to add a new task or agent
