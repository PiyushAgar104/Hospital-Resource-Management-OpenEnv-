# API Reference

Complete reference for the `HospitalEnv` Python API and HTTP endpoints.

---

## Python API

### `HospitalEnv`

```python
from environment import HospitalEnv
env = HospitalEnv()
```

#### `reset(task_id, seed=None) → (Observation, EnvConfig)`

Start a new episode.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `task_id` | `str` | required | One of `"task1_single_ward"`, `"task2_multi_ward"`, `"task3_surge_crisis"` |
| `seed` | `int \| None` | `None` | RNG seed; if `None`, uses the task default |

Returns a tuple of `(Observation, EnvConfig)`.

Raises `ValueError` for unknown `task_id`.

---

#### `step(action) → StepResult`

Advance the simulation by one day.

| Parameter | Type | Description |
|-----------|------|-------------|
| `action` | `AgentAction` | The agent's decisions for today |

Raises `RuntimeError` if called after `done == True`.

**`StepResult` fields:**

| Field | Type | Description |
|-------|------|-------------|
| `observation` | `Observation` | Full next state |
| `reward` | `float` | Shaped reward ∈ [−1.0, +1.0] |
| `done` | `bool` | `True` when `day == episode_length` |
| `truncated` | `bool` | Always `False` |
| `info` | `dict` | `{day, events, mortality_today, stockout_count, day_cost, service_level, bed_utilization}` |

---

#### `state() → Observation`

Return the current observation without advancing the simulation.

---

#### `score() → EpisodeScore`

Grade the completed episode. Call after `done == True`.

Raises `RuntimeError` if episode is not finished.

**`EpisodeScore` fields:**

| Field | Type | Description |
|-------|------|-------------|
| `task_id` | `str` | Task identifier |
| `score` | `float` | Weighted episode score ∈ [0.0, 1.0] |
| `grade` | `str` | `A` / `B` / `C` / `D` / `F` |
| `metrics` | `dict` | Raw KPIs (mortality, stockouts, cost/patient, etc.) |
| `breakdown` | `dict` | Per-criterion sub-scores |
| `notes` | `str` | Human-readable improvement suggestions |

---

#### `available_tasks() → List[str]`

Return all registered task IDs.

#### `task_info(task_id) → dict`

Return metadata for a task: `difficulty`, `episode_length`, `scenario`, `n_units`, `n_medications`, `description`.

---

### `AgentAction`

```python
from environment.models import AgentAction, MedOrderAction, StaffAssignAction, BedTransferAction, DischargeAction

action = AgentAction(
    med_orders    = [...],   # List[MedOrderAction]
    staff_assign  = [...],   # List[StaffAssignAction]
    bed_transfers = [...],   # List[BedTransferAction]
    discharges    = [...],   # List[DischargeAction]
)
```

All fields default to empty lists. All fields are optional — omit any you don't need.

#### `MedOrderAction`

| Field | Type | Description |
|-------|------|-------------|
| `med_id` | `str` | Medication identifier from `cfg.medications` |
| `quantity` | `int ≥ 0` | Units to order |
| `rush` | `bool` | `True` = 1-day delivery, 2× unit cost |

Each `med_id` may appear at most once per action.

#### `StaffAssignAction`

| Field | Type | Description |
|-------|------|-------------|
| `unit_id` | `str` | Unit from `cfg.units` |
| `doctors` | `int ≥ 0` | Doctors to assign this shift |
| `nurses` | `int ≥ 0` | Nurses to assign this shift |
| `techs` | `int ≥ 0` | Technicians to assign this shift |

Values are clamped to pool availability. Omitted units keep their previous schedule.

#### `BedTransferAction`

| Field | Type | Description |
|-------|------|-------------|
| `patient_id` | `str` | Patient `id` from `obs.patients` |
| `to_unit_id` | `str` | Destination unit |

Rejected if destination is at capacity (+3 hallway buffer).

#### `DischargeAction`

| Field | Type | Description |
|-------|------|-------------|
| `patient_id` | `str` | Patient to discharge |

Only `LOW` and `MEDIUM` acuity patients can be discharged early. Earns `$500 + LOS × $200` revenue.

---

### `Observation`

```python
obs.day                    # int — current day (0 at reset)
obs.episode_length         # int
obs.task_id                # str

obs.patients               # List[Patient]
obs.bed_allocations        # List[BedAllocation]

obs.med_inventory          # Dict[str, int] — {med_id: units_on_hand}
obs.pending_med_orders     # List[PendingMedOrder]

obs.current_schedule       # List[StaffSchedule]
obs.staff_pools            # List[StaffPool]

obs.recent_metrics         # List[DailyMetrics] — last 7 days
obs.expected_admissions    # List[dict] — noisy 3-day forecast

obs.cumulative_cost        # float
obs.cumulative_revenue     # float
obs.cumulative_profit      # float
obs.cumulative_mortality   # int
obs.cumulative_stockouts   # int

obs.model_dump()           # → dict (JSON-serialisable)
```

#### `Patient`

```python
p.id                  # str — 8-char UUID fragment
p.acuity              # PatientAcuity: low/medium/high/critical
p.unit_id             # str
p.admission_day       # int
p.expected_los        # int — expected length of stay (days)
p.meds_needed         # Dict[str, int] — {med_id: units_per_day}
p.deterioration_risk  # float ∈ [0, 1] — daily probability of worsening
```

#### `DailyMetrics` (in `obs.recent_metrics`)

```python
m.day                  # int
m.admissions           # int
m.discharges           # int
m.transfers            # int
m.mortality_events     # int
m.stockout_incidents   # int
m.understaffed_shifts  # int
m.bed_utilization      # float ∈ [0, 1]
m.service_level        # float ∈ [0, 1]  — fulfilled / demanded meds
m.total_cost           # float
m.total_revenue        # float
m.profit               # float
```

---

### `EnvConfig` (returned by `reset()`)

```python
cfg.task_id                         # str
cfg.episode_length                  # int
cfg.units                           # List[HospitalUnit]
cfg.medications                     # List[Medication]
cfg.staff_pools                     # List[StaffPool]
cfg.action_space_description        # dict
cfg.observation_space_description   # dict
cfg.reward_description              # str
```

#### `HospitalUnit`

```python
u.id                 # str
u.name               # str
u.unit_type          # UnitType: icu/general/emergency/surgery
u.bed_capacity       # int
u.min_nurse_ratio    # float — nurses per occupied bed (minimum)
u.min_doctor_ratio   # float — doctors per occupied bed (minimum)
```

#### `Medication`

```python
m.id                    # str
m.name                  # str
m.category              # MedCategory
m.unit_cost             # float ($)
m.holding_cost_per_day  # float ($ per unit per day)
m.stockout_penalty      # float ($ per unfulfilled unit)
m.lead_time_days        # int (standard delivery)
m.shelf_life_days       # int
m.max_order_qty         # int
m.critical              # bool — True if stockout worsens mortality risk
```

---

## HTTP API

Start the server:

```bash
python server.py                      # http://localhost:7860
python server.py --host 0.0.0.0 --port 8080
```

All requests and responses use `Content-Type: application/json`.

---

### `GET /health`

```json
{"status": "ok", "version": "1.0.0", "tasks": ["task1_single_ward", ...]}
```

---

### `GET /tasks`

```json
{
  "task1_single_ward": {
    "task_id": "task1_single_ward",
    "difficulty": "easy",
    "episode_length": 30,
    "scenario": "normal",
    "description": "...",
    "n_units": 1,
    "n_medications": 4
  },
  ...
}
```

---

### `POST /reset`

Request:
```json
{"task_id": "task2_multi_ward", "seed": 42}
```

Response:
```json
{
  "observation": {...},
  "config": {...},
  "message": "Episode started: task2_multi_ward"
}
```

---

### `POST /step`

Request:
```json
{
  "action": {
    "med_orders": [
      {"med_id": "vancomycin", "quantity": 100, "rush": false},
      {"med_id": "morphine",   "quantity": 50,  "rush": true}
    ],
    "staff_assign": [
      {"unit_id": "icu",      "doctors": 4, "nurses": 12, "techs": 3},
      {"unit_id": "gen_ward", "doctors": 3, "nurses": 8,  "techs": 2}
    ],
    "bed_transfers": [
      {"patient_id": "a3f9b2c1", "to_unit_id": "icu"}
    ],
    "discharges": [
      {"patient_id": "7d2e1a4f"}
    ]
  }
}
```

Response:
```json
{
  "observation": {...},
  "reward": 0.412,
  "done": false,
  "truncated": false,
  "info": {
    "day": 5,
    "events": [],
    "mortality_today": 0,
    "stockout_count": 1,
    "day_cost": 42381.50,
    "service_level": 0.921,
    "bed_utilization": 0.847
  }
}
```

---

### `GET /state`

Returns current `observation` dict (same schema as in `/step` response).

---

### `GET /score`

Returns `EpisodeScore` dict. Call after `done == true`.

```json
{
  "task_id": "task2_multi_ward",
  "score": 0.8070,
  "grade": "B",
  "metrics": {
    "avg_service_level": 0.951,
    "total_mortality": 1,
    "total_stockouts": 2,
    "total_patients": 287,
    "avg_bed_utilization": 0.813,
    "total_cost": 531420.0,
    "cost_per_patient": 1853.0
  },
  "breakdown": {
    "service_level": 0.951,
    "patient_safety": 0.952,
    "cost_efficiency": 0.721,
    "bed_utilization": 0.742,
    "transfer_timing": 0.479
  },
  "notes": "Strong multi-ward coordination."
}
```

---

### `POST /demo`

Run a complete episode server-side and return a full log. Useful for testing without implementing the step loop yourself.

Request:
```json
{"task_id": "task3_surge_crisis", "agent": "heuristic", "seed": 42}
```

Response:
```json
{
  "task_id": "task3_surge_crisis",
  "agent": "heuristic",
  "seed": 42,
  "total_reward": 34.21,
  "final_score": {...},
  "daily_log": [
    {"day": 1, "reward": 0.635, "service_level": 1.0, "bed_utilization": 0.31, ...},
    ...
  ]
}
```

---

## Enumerations

```python
from environment.models import PatientAcuity, UnitType, StaffRole, MedCategory

PatientAcuity.LOW      # "low"
PatientAcuity.MEDIUM   # "medium"
PatientAcuity.HIGH     # "high"
PatientAcuity.CRITICAL # "critical"

UnitType.ICU           # "icu"
UnitType.GENERAL       # "general"
UnitType.EMERGENCY     # "emergency"
UnitType.SURGERY       # "surgery"

StaffRole.DOCTOR       # "doctor"
StaffRole.NURSE        # "nurse"
StaffRole.TECH         # "technician"

MedCategory.ANTIBIOTIC    # "antibiotic"
MedCategory.ANALGESIC     # "analgesic"
MedCategory.CARDIAC       # "cardiac"
MedCategory.SEDATIVE      # "sedative"
MedCategory.BLOOD_PRODUCT # "blood_product"
```
