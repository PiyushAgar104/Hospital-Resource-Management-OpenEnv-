#!/usr/bin/env python3
"""
Hospital Resource Management OpenEnv — Standalone HTTP Server

Zero-dependency API server using only Python stdlib + numpy.
Implements the full OpenEnv HTTP spec without FastAPI or Gradio.

Usage:
    python server.py               # starts on http://localhost:7860
    python server.py --port 8080
    python server.py --host 0.0.0.0 --port 7860

Endpoints mirror app.py:
    GET  /health
    GET  /tasks
    GET  /state
    GET  /score
    POST /reset      body: {"task_id": "...", "seed": 42}
    POST /step       body: {"action": {...}}
"""
from __future__ import annotations

import argparse
import json
import sys
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Dict, Optional
from urllib.parse import urlparse

# Allow running from project root
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from environment import HospitalEnv
from environment.models import AgentAction, MedOrderAction, StaffAssignAction, BedTransferAction, DischargeAction
from baseline.agent import HeuristicAgent, RandomAgent, GreedyAgent


# ─── Global state ─────────────────────────────────────────────────────────────
_env = HospitalEnv()
_last_obs = None
_last_cfg = None
_episode_active = False


# ─── JSON helpers ─────────────────────────────────────────────────────────────

def _ok(data: Any) -> bytes:
    return json.dumps(data, default=str).encode()


def _err(msg: str, code: int = 400) -> tuple:
    return code, json.dumps({"error": msg}).encode()


def _parse_action(raw: Dict) -> AgentAction:
    return AgentAction(
        med_orders=[MedOrderAction(**o) for o in raw.get("med_orders", [])],
        staff_assign=[StaffAssignAction(**s) for s in raw.get("staff_assign", [])],
        bed_transfers=[BedTransferAction(**t) for t in raw.get("bed_transfers", [])],
        discharges=[DischargeAction(**d) for d in raw.get("discharges", [])],
    )


# ─── Request handlers ─────────────────────────────────────────────────────────

def handle_health(_body) -> tuple:
    return 200, _ok({"status": "ok", "version": "1.0.0", "tasks": _env.available_tasks()})


def handle_tasks(_body) -> tuple:
    return 200, _ok({t: _env.task_info(t) for t in _env.available_tasks()})


def handle_reset(body: Dict) -> tuple:
    global _last_obs, _last_cfg, _episode_active
    task_id = body.get("task_id", "task1_single_ward")
    seed = body.get("seed", None)
    try:
        obs, cfg = _env.reset(task_id=task_id, seed=seed)
        _last_obs, _last_cfg = obs, cfg
        _episode_active = True
        return 200, _ok({
            "observation": obs.model_dump(),
            "config": cfg.model_dump(),
            "message": f"Episode started: {task_id}",
        })
    except ValueError as e:
        return _err(str(e))


def handle_step(body: Dict) -> tuple:
    global _last_obs, _episode_active
    if not _episode_active:
        return _err("No active episode — call /reset first.")
    try:
        action = _parse_action(body.get("action", {}))
        result = _env.step(action)
        _last_obs = result.observation
        if result.done:
            _episode_active = False
        return 200, _ok(result.model_dump())
    except RuntimeError as e:
        return _err(str(e))
    except Exception as e:
        return _err(f"Action parse error: {e}", 422)


def handle_state(_body) -> tuple:
    if _last_obs is None:
        return _err("No active episode.")
    return 200, _ok(_last_obs.model_dump())


def handle_score(_body) -> tuple:
    try:
        s = _env.score()
        return 200, _ok(s.model_dump())
    except RuntimeError as e:
        return _err(str(e))


def handle_demo(body: Dict) -> tuple:
    """Run a full demo episode with selected agent, return summary."""
    task_id = body.get("task_id", "task1_single_ward")
    agent_name = body.get("agent", "heuristic")
    seed = body.get("seed", 42)

    agents = {"random": lambda: RandomAgent(seed=0), "heuristic": HeuristicAgent, "greedy": GreedyAgent}
    if agent_name not in agents:
        return _err(f"Unknown agent '{agent_name}'. Choose from: {list(agents)}")

    env = HospitalEnv()
    agent = agents[agent_name]()
    try:
        obs, cfg = env.reset(task_id=task_id, seed=seed)
    except ValueError as e:
        return _err(str(e))

    daily_log = []
    total_reward = 0.0
    while True:
        action = agent.act(obs, cfg)
        result = env.step(action)
        obs = result.observation
        total_reward += result.reward
        if obs.recent_metrics:
            m = obs.recent_metrics[-1]
            daily_log.append({
                "day": m.day,
                "reward": round(result.reward, 4),
                "service_level": round(m.service_level, 3),
                "bed_utilization": round(m.bed_utilization, 3),
                "patients": len(obs.patients),
                "mortality": m.mortality_events,
                "stockouts": m.stockout_incidents,
                "cost": round(m.total_cost, 2),
                "revenue": round(m.total_revenue, 2),
            })
        if result.done:
            break

    score = env.score()
    return 200, _ok({
        "task_id": task_id,
        "agent": agent_name,
        "seed": seed,
        "total_reward": round(total_reward, 4),
        "final_score": score.model_dump(),
        "daily_log": daily_log,
    })


# ─── Route table ──────────────────────────────────────────────────────────────

ROUTES: Dict[str, Dict[str, Any]] = {
    "GET":  {"/health": handle_health, "/tasks": handle_tasks,
             "/state": handle_state, "/score": handle_score},
    "POST": {"/reset": handle_reset, "/step": handle_step, "/demo": handle_demo},
}

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hospital OpenEnv Dashboard</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #0f1117; color: #e2e8f0; min-height: 100vh; }
  header { background: linear-gradient(135deg,#1e3a5f,#0d2137); padding: 24px 32px; border-bottom: 1px solid #2d3748; display:flex; align-items:center; gap:16px; }
  header h1 { font-size:1.5rem; font-weight:700; color:#63b3ed; }
  header span { color:#718096; font-size:.9rem; }
  .container { max-width:1100px; margin:0 auto; padding:24px; }
  .card { background:#1a2535; border:1px solid #2d3748; border-radius:12px; padding:20px; margin-bottom:20px; }
  .card h2 { font-size:1rem; font-weight:600; color:#63b3ed; margin-bottom:14px; text-transform:uppercase; letter-spacing:.05em; }
  .controls { display:grid; grid-template-columns:1fr 1fr 1fr auto; gap:12px; align-items:end; }
  label { font-size:.8rem; color:#a0aec0; display:block; margin-bottom:4px; }
  select, button { width:100%; padding:9px 12px; border-radius:8px; border:1px solid #2d3748; font-size:.9rem; }
  select { background:#0f1117; color:#e2e8f0; }
  .btn-run { background:linear-gradient(135deg,#2b6cb0,#2c5282); color:white; cursor:pointer; font-weight:600; border:none; }
  .btn-run:hover { background:linear-gradient(135deg,#3182ce,#2b6cb0); }
  .btn-run:disabled { opacity:.5; cursor:not-allowed; }
  .metrics { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; }
  .metric { background:#0f1117; border-radius:8px; padding:14px; text-align:center; }
  .metric .val { font-size:1.6rem; font-weight:700; color:#63b3ed; }
  .metric .lbl { font-size:.72rem; color:#718096; margin-top:4px; text-transform:uppercase; }
  .score-circle { display:inline-flex; flex-direction:column; align-items:center; justify-content:center;
    width:100px; height:100px; border-radius:50%; border:4px solid #2b6cb0;
    font-size:1.8rem; font-weight:800; color:#63b3ed; margin: 0 auto 8px; }
  .grade-badge { display:inline-block; padding:2px 12px; border-radius:99px; font-weight:700; font-size:.85rem; }
  .grade-A { background:#22543d; color:#9ae6b4; }
  .grade-B { background:#234e52; color:#81e6d9; }
  .grade-C { background:#744210; color:#fbd38d; }
  .grade-D { background:#63171b; color:#fc8181; }
  .grade-F { background:#2d3748; color:#a0aec0; }
  .chart-wrap { overflow-x:auto; padding-top:8px; }
  table { width:100%; border-collapse:collapse; font-size:.82rem; }
  th { background:#0f1117; color:#718096; padding:8px 10px; text-align:right; font-weight:600; position:sticky; top:0; }
  th:first-child { text-align:center; }
  td { padding:7px 10px; border-top:1px solid #1e2d40; text-align:right; }
  td:first-child { text-align:center; font-weight:600; color:#a0aec0; }
  tr:hover td { background:#1e2535; }
  .bar-wrap { display:flex; align-items:center; gap:6px; }
  .bar { height:10px; border-radius:3px; transition:width .3s; }
  .bar-svc { background:#3182ce; }
  .bar-bed { background:#38a169; }
  .bar-val { font-size:.75rem; color:#a0aec0; min-width:36px; }
  .log { font-family:'Courier New',monospace; font-size:.78rem; background:#0a0e17;
    padding:14px; border-radius:8px; max-height:200px; overflow-y:auto; color:#68d391; }
  .breakdown { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
  .bk-row { display:flex; justify-content:space-between; align-items:center; padding:6px 10px;
    background:#0f1117; border-radius:6px; }
  .bk-name { font-size:.8rem; color:#a0aec0; }
  .bk-bar-wrap { flex:1; margin:0 10px; }
  .bk-bar { height:6px; border-radius:3px; background:linear-gradient(90deg,#2b6cb0,#63b3ed); }
  .bk-score { font-size:.85rem; font-weight:700; color:#63b3ed; min-width:38px; text-align:right; }
  .spinner { display:inline-block; width:16px; height:16px; border:2px solid #2d3748;
    border-top-color:#63b3ed; border-radius:50%; animation:spin .7s linear infinite; vertical-align:middle; margin-right:6px; }
  @keyframes spin { to { transform:rotate(360deg); } }
  .hidden { display:none; }
  .results-grid { display:grid; grid-template-columns:140px 1fr; gap:16px; align-items:start; }
  .score-col { display:flex; flex-direction:column; align-items:center; gap:8px; }
  .event-tag { display:inline-block; background:#744210; color:#fbd38d; font-size:.7rem;
    padding:2px 7px; border-radius:4px; margin:2px; }
</style>
</head>
<body>
<header>
  <div>🏥</div>
  <div>
    <h1>Hospital Resource Management OpenEnv</h1>
    <span>OpenEnv 1.0 · Real-World AI Environment · step() / reset() / state() / score()</span>
  </div>
</header>
<div class="container">

  <!-- Controls -->
  <div class="card">
    <h2>Run Episode</h2>
    <div class="controls">
      <div>
        <label>Task</label>
        <select id="task">
          <option value="task1_single_ward">Task 1 – Single Ward (Easy, 30d)</option>
          <option value="task2_multi_ward" selected>Task 2 – Multi Ward (Medium, 60d)</option>
          <option value="task3_surge_crisis">Task 3 – Surge Crisis (Hard, 90d)</option>
        </select>
      </div>
      <div>
        <label>Agent</label>
        <select id="agent">
          <option value="random">Random (lower bound)</option>
          <option value="heuristic" selected>Heuristic (reorder-point)</option>
          <option value="greedy">Greedy (forecast-aware)</option>
        </select>
      </div>
      <div>
        <label>Seed</label>
        <select id="seed">
          <option value="42">42 (default)</option>
          <option value="123">123</option>
          <option value="999">999</option>
          <option value="7">7</option>
        </select>
      </div>
      <div>
        <button class="btn-run" id="runBtn" onclick="runEpisode()">▶ Run Episode</button>
      </div>
    </div>
  </div>

  <!-- Score summary (hidden until run) -->
  <div class="card hidden" id="scoreCard">
    <h2>Episode Results</h2>
    <div class="results-grid">
      <div class="score-col">
        <div class="score-circle" id="scoreCircle">—</div>
        <div id="gradeBadge">—</div>
        <div style="font-size:.75rem;color:#718096;text-align:center;" id="taskLabel">—</div>
      </div>
      <div>
        <div class="metrics" id="metricBoxes" style="margin-bottom:14px;"></div>
        <div class="breakdown" id="breakdown"></div>
      </div>
    </div>
  </div>

  <!-- Daily chart (hidden until run) -->
  <div class="card hidden" id="chartCard">
    <h2>Daily Performance Log</h2>
    <div class="chart-wrap">
      <table id="dayTable">
        <thead>
          <tr>
            <th>Day</th>
            <th>Reward</th>
            <th style="text-align:left;padding-left:10px">Service Level</th>
            <th style="text-align:left;padding-left:10px">Bed Util</th>
            <th>Patients</th>
            <th>Deaths</th>
            <th>Stockouts</th>
            <th>Cost ($)</th>
          </tr>
        </thead>
        <tbody id="dayBody"></tbody>
      </table>
    </div>
  </div>

  <!-- API Reference quick-ref -->
  <div class="card">
    <h2>HTTP API</h2>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:.82rem;">
      <div>
        <div style="color:#718096;margin-bottom:8px;">Endpoints</div>
        <div style="display:flex;flex-direction:column;gap:6px;">
          <code style="background:#0f1117;padding:5px 10px;border-radius:5px;color:#68d391;">POST /reset  {"task_id":"task1_single_ward","seed":42}</code>
          <code style="background:#0f1117;padding:5px 10px;border-radius:5px;color:#63b3ed;">POST /step   {"action":{...}}</code>
          <code style="background:#0f1117;padding:5px 10px;border-radius:5px;color:#a0aec0;">GET  /state</code>
          <code style="background:#0f1117;padding:5px 10px;border-radius:5px;color:#a0aec0;">GET  /score</code>
          <code style="background:#0f1117;padding:5px 10px;border-radius:5px;color:#fbd38d;">POST /demo   {"task_id":"...","agent":"heuristic"}</code>
        </div>
      </div>
      <div>
        <div style="color:#718096;margin-bottom:8px;">Reward function (dense, ∈ [−1, +1])</div>
        <code style="background:#0f1117;padding:10px;border-radius:5px;display:block;line-height:1.7;color:#e2e8f0;font-size:.78rem;">
r = w_svc  × service_level<br>
  + w_safe × (1 − mortality_rate)<br>
  − w_cost × (day_cost / revenue)<br>
  + w_bed  × bed_util_score<br>
  + 0.5 (terminal bonus if score ≥ 0.80)
        </code>
      </div>
    </div>
  </div>

</div>
<script>
async function runEpisode() {
  const btn = document.getElementById('runBtn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>Running…';
  document.getElementById('scoreCard').classList.add('hidden');
  document.getElementById('chartCard').classList.add('hidden');

  const task   = document.getElementById('task').value;
  const agent  = document.getElementById('agent').value;
  const seed   = parseInt(document.getElementById('seed').value);

  try {
    const resp = await fetch('/demo', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({task_id: task, agent, seed})
    });
    const data = await resp.json();
    if (data.error) { alert(data.error); return; }
    renderResults(data);
  } catch(e) {
    alert('Server error: ' + e.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = '▶ Run Episode';
  }
}

function renderResults(data) {
  const score = data.final_score;
  const log   = data.daily_log;

  // Score circle
  const s = score.score;
  document.getElementById('scoreCircle').textContent = s.toFixed(3);
  document.getElementById('scoreCircle').style.borderColor = scoreColor(s);
  document.getElementById('scoreCircle').style.color = scoreColor(s);
  const grade = score.grade;
  document.getElementById('gradeBadge').innerHTML = `<span class="grade-badge grade-${grade}">${grade}</span>`;
  document.getElementById('taskLabel').textContent = `${data.task_id} · ${data.agent} · seed ${data.seed}`;

  // KPI boxes
  const m = score.metrics;
  const boxes = [
    {val: (m.avg_service_level*100).toFixed(1)+'%', lbl:'Avg Service Level'},
    {val: m.total_mortality ?? 0,                   lbl:'Total Mortality'},
    {val: m.total_stockouts ?? 0,                   lbl:'Stockout Days'},
    {val: '$'+(m.cost_per_patient??0).toLocaleString(undefined,{maximumFractionDigits:0}), lbl:'Cost / Patient'},
  ];
  document.getElementById('metricBoxes').innerHTML = boxes.map(b =>
    `<div class="metric"><div class="val">${b.val}</div><div class="lbl">${b.lbl}</div></div>`
  ).join('');

  // Breakdown bars
  document.getElementById('breakdown').innerHTML = Object.entries(score.breakdown).map(([k,v]) =>
    `<div class="bk-row">
      <span class="bk-name">${k.replace(/_/g,' ')}</span>
      <div class="bk-bar-wrap"><div class="bk-bar" style="width:${(v*100).toFixed(0)}%"></div></div>
      <span class="bk-score">${v.toFixed(3)}</span>
    </div>`
  ).join('');

  document.getElementById('scoreCard').classList.remove('hidden');

  // Daily table
  const tbody = document.getElementById('dayBody');
  tbody.innerHTML = log.map(d => `
    <tr>
      <td>${d.day}</td>
      <td style="color:${d.reward>=0?'#68d391':'#fc8181'};font-weight:600">${d.reward>0?'+':''}${d.reward.toFixed(3)}</td>
      <td>
        <div class="bar-wrap">
          <div class="bar bar-svc" style="width:${(d.service_level*80).toFixed(0)}px"></div>
          <span class="bar-val">${(d.service_level*100).toFixed(0)}%</span>
        </div>
      </td>
      <td>
        <div class="bar-wrap">
          <div class="bar bar-bed" style="width:${(d.bed_utilization*80).toFixed(0)}px"></div>
          <span class="bar-val">${(d.bed_utilization*100).toFixed(0)}%</span>
        </div>
      </td>
      <td>${d.patients}</td>
      <td style="color:${d.mortality>0?'#fc8181':'#a0aec0'}">${d.mortality}</td>
      <td style="color:${d.stockouts>0?'#fbd38d':'#a0aec0'}">${d.stockouts}</td>
      <td style="color:#718096">$${d.cost.toLocaleString(undefined,{maximumFractionDigits:0})}</td>
    </tr>`).join('');

  document.getElementById('chartCard').classList.remove('hidden');
  document.getElementById('dayTable').scrollIntoView({behavior:'smooth', block:'nearest'});
}

function scoreColor(s) {
  if (s >= 0.90) return '#68d391';
  if (s >= 0.80) return '#63b3ed';
  if (s >= 0.70) return '#fbd38d';
  if (s >= 0.55) return '#fc8181';
  return '#a0aec0';
}
</script>
</body>
</html>
"""


# ─── HTTP handler ─────────────────────────────────────────────────────────────

class OpenEnvHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"  {self.address_string()} [{self.log_date_time_string()}] {fmt % args}")

    def _read_body(self) -> Dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {}

    def _send(self, code: int, body: bytes, content_type: str = "application/json"):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send(204, b"")

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/dashboard"):
            self._send(200, DASHBOARD_HTML.encode(), "text/html; charset=utf-8")
            return
        handler = ROUTES["GET"].get(path)
        if handler is None:
            self._send(404, json.dumps({"error": f"Unknown endpoint: {path}"}).encode())
            return
        code, body = handler({})
        self._send(code, body)

    def do_POST(self):
        path = urlparse(self.path).path
        handler = ROUTES["POST"].get(path)
        if handler is None:
            self._send(404, json.dumps({"error": f"Unknown endpoint: {path}"}).encode())
            return
        body = self._read_body()
        code, resp_body = handler(body)
        self._send(code, resp_body)


# ─── Entry point ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Hospital OpenEnv HTTP Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=7860)
    args = parser.parse_args()

    server = HTTPServer((args.host, args.port), OpenEnvHandler)
    print(f"\n{'='*60}")
    print(f"  🏥 Hospital Resource Management OpenEnv")
    print(f"  Server running at http://{args.host}:{args.port}")
    print(f"  Dashboard:  http://localhost:{args.port}/")
    print(f"  API health: http://localhost:{args.port}/health")
    print(f"  Task list:  http://localhost:{args.port}/tasks")
    print(f"{'='*60}")
    print("  Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.shutdown()


if __name__ == "__main__":
    main()
