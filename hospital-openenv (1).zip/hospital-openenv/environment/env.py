"""
HospitalEnv – Hospital Resource Management OpenEnv

Implements the OpenEnv standard API:
  - reset(task_id, seed) → (Observation, EnvConfig)
  - step(action)         → StepResult
  - state()              → Observation
  - score()              → EpisodeScore   (call after done==True)

The reward function is dense and shaped:
  r = w_svc * Δservice_level + w_safe * Δpatient_safety
      - w_cost * cost_today / cost_budget
      + w_bed * bed_util_score
  clipped to [−1, +1]
"""
from __future__ import annotations

import copy
import math
import random
import uuid
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from environment.graders.graders import grade_episode
from environment.models import (
    AgentAction,
    BedAllocation,
    BedTransferAction,
    DailyMetrics,
    DischargeAction,
    EnvConfig,
    EpisodeScore,
    HospitalUnit,
    Medication,
    MedOrderAction,
    Observation,
    PatientAcuity,
    Patient,
    PendingMedOrder,
    StaffAssignAction,
    StaffPool,
    StaffRole,
    StaffSchedule,
    StepResult,
    UnitType,
)
from environment.simulator.demand import DemandSimulator
from environment.tasks.tasks import ALL_TASKS


class HospitalEnv:
    """
    Hospital Resource Management OpenEnv.

    Usage
    -----
    env = HospitalEnv()
    obs, cfg = env.reset("task1_single_ward")
    while True:
        action = agent.act(obs, cfg)
        result = env.step(action)
        obs = result.observation
        if result.done:
            score = env.score()
            break
    """

    def __init__(self) -> None:
        self._task_id: Optional[str] = None
        self._task_cfg: Optional[Dict] = None
        self._day: int = 0
        self._episode_length: int = 0
        self._done: bool = True

        # Dynamic state
        self._patients: List[Patient] = []
        self._med_inventory: Dict[str, int] = {}
        self._pending_orders: List[PendingMedOrder] = []
        self._schedules: Dict[str, Dict[str, int]] = {}   # unit_id → {role: count}
        self._staff_pools: List[StaffPool] = []
        self._units: Dict[str, HospitalUnit] = {}
        self._medications: Dict[str, Medication] = {}

        # History
        self._metrics_history: List[DailyMetrics] = []
        self._total_admissions: int = 0
        self._cumulative_cost: float = 0.0
        self._cumulative_revenue: float = 0.0
        self._cumulative_mortality: int = 0
        self._cumulative_stockouts: int = 0

        # Previous-day values for reward delta
        self._prev_service_level: float = 1.0
        self._prev_mortality_events: int = 0

        self._simulator: Optional[DemandSimulator] = None
        self._rng: random.Random = random.Random(42)

        # Crisis event state for task 3
        self._active_supply_blocks: Dict[str, int] = {}   # med_id → days_remaining
        self._staff_strike_days_left: int = 0
        self._strike_reduction: float = 0.0

    # ────────────────────────────────────────────────────────────────────────
    #  OpenEnv API
    # ────────────────────────────────────────────────────────────────────────

    def reset(
        self,
        task_id: str = "task1_single_ward",
        seed: Optional[int] = None,
    ) -> Tuple[Observation, EnvConfig]:
        """
        Reset the environment to the start of a new episode.

        Returns
        -------
        observation : Observation
            Initial environment state.
        config : EnvConfig
            Static environment description (action/observation space, etc.)
        """
        if task_id not in ALL_TASKS:
            raise ValueError(f"Unknown task '{task_id}'. Valid: {list(ALL_TASKS)}")

        task = ALL_TASKS[task_id]
        effective_seed = seed if seed is not None else task["seed"]

        # ── Static setup ──────────────────────────────────────────────────
        self._task_id = task_id
        self._task_cfg = task
        self._episode_length = task["episode_length"]
        self._day = 0
        self._done = False

        self._units = {u.id: u for u in task["units"]}
        self._medications = {m.id: m for m in task["medications"]}
        self._staff_pools = copy.deepcopy(task["staff_pools"])
        self._rng = random.Random(effective_seed)

        # ── Dynamic state ─────────────────────────────────────────────────
        self._patients = []
        self._med_inventory = copy.deepcopy(task["initial_inventory"])
        self._pending_orders = []
        self._schedules = copy.deepcopy(task["initial_staff_schedule"])
        self._metrics_history = []
        self._total_admissions = 0
        self._cumulative_cost = 0.0
        self._cumulative_revenue = 0.0
        self._cumulative_mortality = 0
        self._cumulative_stockouts = 0
        self._prev_service_level = 1.0
        self._prev_mortality_events = 0
        self._active_supply_blocks = {}
        self._staff_strike_days_left = 0
        self._strike_reduction = 0.0

        self._simulator = DemandSimulator(
            units=task["units"],
            medications=task["medications"],
            seed=effective_seed,
            scenario=task.get("scenario", "normal"),
        )

        # ── Build observation & config ────────────────────────────────────
        obs = self._build_observation()
        cfg = EnvConfig(
            task_id=task_id,
            episode_length=self._episode_length,
            units=task["units"],
            medications=task["medications"],
            staff_pools=self._staff_pools,
            action_space_description=task["action_space_description"],
            observation_space_description=task["observation_space_description"],
            reward_description=(
                "Dense reward in [−1, +1]. Components: "
                "+service_level_delta, +patient_safety_delta, "
                "−cost_fraction, +bed_utilisation_score. "
                "Terminal bonus: +0.5 if final score ≥ 0.80."
            ),
        )
        return obs, cfg

    def step(self, action: AgentAction) -> StepResult:
        """
        Advance the environment by one day.

        Parameters
        ----------
        action : AgentAction
            The agent's decisions for today.

        Returns
        -------
        StepResult with observation, reward, done, truncated, info.
        """
        if self._done:
            raise RuntimeError("Episode is done. Call reset() to start a new episode.")

        self._day += 1
        info: Dict[str, Any] = {"day": self._day, "events": []}

        # 1. Apply crisis events (task 3)
        self._apply_crisis_events(info)

        # 2. Receive pending medication deliveries
        self._receive_deliveries()

        # 3. Process agent actions
        action_cost = self._process_orders(action.med_orders, info)
        action_cost += self._process_staffing(action.staff_assign, info)
        self._process_transfers(action.bed_transfers, info)
        discharge_revenue = self._process_discharges(action.discharges, info)

        # 4. Simulate patient arrivals
        new_admissions = self._simulate_arrivals()
        self._total_admissions += new_admissions
        info["admissions"] = new_admissions

        # 5. Compute medication demand and fulfil
        med_demand = self._simulator.compute_daily_med_demand(self._patients)
        med_fulfilled, stockout_count = self._fulfil_med_demand(med_demand)
        stockout_cost = self._compute_stockout_cost(med_demand, med_fulfilled)
        self._cumulative_stockouts += stockout_count

        # 6. Compute staffing ratios and patient outcomes
        staffing_ratios = self._compute_staffing_ratios()
        med_supply_ratios = self._compute_med_supply_ratios(med_demand, med_fulfilled)
        mortality_today, deteriorations = self._process_patient_outcomes(
            staffing_ratios, med_supply_ratios
        )
        self._cumulative_mortality += mortality_today

        # 7. Natural discharges (not triggered by agent)
        natural_discharges = self._process_natural_discharges()

        # 8. Costs
        holding_cost = self._compute_holding_cost()
        staffing_cost = self._compute_staffing_cost()
        day_cost = action_cost + holding_cost + staffing_cost + stockout_cost
        revenue = self._compute_revenue(med_demand, med_fulfilled) + discharge_revenue
        self._cumulative_cost += day_cost
        self._cumulative_revenue += revenue

        # 9. Build daily metrics
        daily = self._build_daily_metrics(
            admissions=new_admissions,
            discharges=len(action.discharges) + natural_discharges,
            transfers=len(action.bed_transfers),
            mortality=mortality_today,
            stockouts=stockout_count,
            understaffed_shifts=self._count_understaffed(),
            med_demand=med_demand,
            med_fulfilled=med_fulfilled,
            day_cost=day_cost,
            revenue=revenue,
        )
        self._metrics_history.append(daily)

        # 10. Reward
        reward = self._compute_reward(daily, day_cost)
        self._prev_service_level = daily.service_level
        self._prev_mortality_events = mortality_today

        # 11. Done?
        done = self._day >= self._episode_length
        if done:
            self._done = True
            final_score = grade_episode(
                self._task_id,
                self._metrics_history,
                self._total_admissions,
            )
            if final_score.score >= 0.80:
                reward += 0.5   # terminal bonus
            info["final_score"] = final_score.model_dump()

        info.update({
            "mortality_today":   mortality_today,
            "deteriorations":    deteriorations,
            "stockout_count":    stockout_count,
            "day_cost":          round(day_cost, 2),
            "service_level":     round(daily.service_level, 3),
            "bed_utilization":   round(daily.bed_utilization, 3),
        })

        obs = self._build_observation()
        return StepResult(
            observation=obs,
            reward=round(max(-1.0, min(1.0, reward)), 4),
            done=done,
            truncated=False,
            info=info,
        )

    def state(self) -> Observation:
        """Return current environment state without advancing the simulation."""
        return self._build_observation()

    def score(self) -> EpisodeScore:
        """Grade the completed episode. Must be called after done==True."""
        if not self._done and self._day < self._episode_length:
            raise RuntimeError("Episode not finished yet.")
        return grade_episode(
            self._task_id,
            self._metrics_history,
            self._total_admissions,
        )

    # ────────────────────────────────────────────────────────────────────────
    #  Internal helpers
    # ────────────────────────────────────────────────────────────────────────

    # ── Crisis events ─────────────────────────────────────────────────────

    def _apply_crisis_events(self, info: Dict) -> None:
        task = self._task_cfg
        crisis_events = task.get("crisis_events", [])

        for event in crisis_events:
            if event["day"] != self._day:
                continue

            etype = event["type"]
            if etype == "supply_disruption":
                med_id = event["med_id"]
                self._active_supply_blocks[med_id] = event["duration"]
                info["events"].append(f"Supply disruption: {med_id} for {event['duration']} days")

            elif etype == "staff_strike":
                self._staff_strike_days_left = event["duration"]
                self._strike_reduction = event["pool_reduction"]
                info["events"].append(
                    f"Staff strike! Pool reduced by {int(event['pool_reduction']*100)}% "
                    f"for {event['duration']} days"
                )

            elif etype == "mass_casualty":
                unit_id = event["unit"]
                unit = self._units.get(unit_id)
                if unit:
                    extra_count = event["extra_arrivals"]
                    for _ in range(extra_count):
                        p = Patient(
                            acuity=PatientAcuity.HIGH,
                            unit_id=unit_id,
                            admission_day=self._day,
                            expected_los=5,
                            meds_needed={"morphine": 3, "vancomycin": 2},
                            deterioration_risk=0.15,
                        )
                        self._patients.append(p)
                    self._total_admissions += extra_count
                    info["events"].append(f"Mass casualty: {extra_count} extra admissions to {unit_id}")

        # Decrement active blocks
        for med_id in list(self._active_supply_blocks):
            self._active_supply_blocks[med_id] -= 1
            if self._active_supply_blocks[med_id] <= 0:
                del self._active_supply_blocks[med_id]

        if self._staff_strike_days_left > 0:
            self._staff_strike_days_left -= 1

    # ── Deliveries ────────────────────────────────────────────────────────

    def _receive_deliveries(self) -> None:
        remaining = []
        for order in self._pending_orders:
            if order.arrival_day <= self._day:
                self._med_inventory[order.med_id] = (
                    self._med_inventory.get(order.med_id, 0) + order.quantity
                )
            else:
                remaining.append(order)
        self._pending_orders = remaining

    # ── Agent action processing ───────────────────────────────────────────

    def _process_orders(self, orders: List[MedOrderAction], info: Dict) -> float:
        cost = 0.0
        for order in orders:
            if order.quantity <= 0:
                continue
            med = self._medications.get(order.med_id)
            if not med:
                info["events"].append(f"Unknown medication: {order.med_id}")
                continue

            # Block if supply disruption active
            if order.med_id in self._active_supply_blocks and not order.rush:
                info["events"].append(
                    f"Order blocked: {order.med_id} supply disrupted (try rush=True)"
                )
                continue

            qty = min(order.quantity, med.max_order_qty)
            unit_cost = med.unit_cost * (2.0 if order.rush else 1.0)
            lead_time = 1 if order.rush else med.lead_time_days
            total = qty * unit_cost
            cost += total

            self._pending_orders.append(
                PendingMedOrder(
                    med_id=order.med_id,
                    quantity=qty,
                    arrival_day=self._day + lead_time,
                    cost=total,
                    rush=order.rush,
                )
            )
        return cost

    def _process_staffing(self, assigns: List[StaffAssignAction], info: Dict) -> float:
        cost = 0.0
        effective_mult = 1.0
        if self._staff_strike_days_left > 0:
            effective_mult = 1.0 - self._strike_reduction

        # Pool capacities
        pool_map = {p.role: p for p in self._staff_pools}
        total_assigned: Dict[StaffRole, int] = {
            StaffRole.DOCTOR: 0, StaffRole.NURSE: 0, StaffRole.TECH: 0
        }

        # First pass: compute totals being assigned
        for assign in assigns:
            total_assigned[StaffRole.DOCTOR] += assign.doctors
            total_assigned[StaffRole.NURSE]  += assign.nurses
            total_assigned[StaffRole.TECH]   += assign.techs

        # Clamp to available pool (with strike multiplier)
        for role, pool in pool_map.items():
            max_avail = int(pool.available * effective_mult)
            if total_assigned[role] > max_avail:
                info["events"].append(
                    f"Staff clamped: {role.value} requested {total_assigned[role]} but only {max_avail} available"
                )

        # Apply assignments (clamped proportionally)
        for assign in assigns:
            if assign.unit_id not in self._units:
                continue
            doc_max  = int(pool_map[StaffRole.DOCTOR].available * effective_mult)
            nurse_max = int(pool_map[StaffRole.NURSE].available  * effective_mult)
            tech_max  = int(pool_map[StaffRole.TECH].available   * effective_mult)

            self._schedules[assign.unit_id] = {
                "doctors": min(assign.doctors, doc_max),
                "nurses":  min(assign.nurses,  nurse_max),
                "techs":   min(assign.techs,   tech_max),
            }

        # Compute staffing cost
        for sched in self._schedules.values():
            cost += sched.get("doctors", 0) * pool_map[StaffRole.DOCTOR].daily_cost
            cost += sched.get("nurses",  0) * pool_map[StaffRole.NURSE].daily_cost
            cost += sched.get("techs",   0) * pool_map[StaffRole.TECH].daily_cost

        return cost

    def _process_transfers(self, transfers: List[BedTransferAction], info: Dict) -> None:
        patient_map = {p.id: p for p in self._patients}
        for transfer in transfers:
            p = patient_map.get(transfer.patient_id)
            if p is None:
                continue
            if transfer.to_unit_id not in self._units:
                continue
            # Check capacity
            target_unit = self._units[transfer.to_unit_id]
            current_census = sum(1 for x in self._patients if x.unit_id == transfer.to_unit_id)
            if current_census >= target_unit.bed_capacity + 3:  # soft cap +3
                info["events"].append(
                    f"Transfer rejected: {transfer.to_unit_id} at capacity"
                )
                continue
            p.unit_id = transfer.to_unit_id
            info["events"].append(f"Transferred patient {p.id} → {transfer.to_unit_id}")

    def _process_discharges(self, discharges: List[DischargeAction], info: Dict) -> float:
        revenue = 0.0
        patient_map = {p.id: p for p in self._patients}
        discharge_ids = set()
        for d in discharges:
            p = patient_map.get(d.patient_id)
            if p is None:
                continue
            # Only allow early discharge of LOW/MEDIUM acuity
            if p.acuity in (PatientAcuity.LOW, PatientAcuity.MEDIUM):
                discharge_ids.add(p.id)
                los = self._day - p.admission_day
                revenue += 500 + los * 200   # DRG-style payment
        self._patients = [p for p in self._patients if p.id not in discharge_ids]
        return revenue

    # ── Arrivals ──────────────────────────────────────────────────────────

    def _simulate_arrivals(self) -> int:
        n = 0
        for unit_id, unit in self._units.items():
            census = sum(1 for p in self._patients if p.unit_id == unit_id)
            new_patients = self._simulator.generate_admissions(
                day=self._day,
                unit_id=unit_id,
                current_census=census,
                bed_capacity=unit.bed_capacity,
            )
            self._patients.extend(new_patients)
            n += len(new_patients)
        return n

    # ── Medication fulfilment ─────────────────────────────────────────────

    def _fulfil_med_demand(
        self, demand: Dict[str, int]
    ) -> Tuple[Dict[str, int], int]:
        fulfilled: Dict[str, int] = {}
        stockout_count = 0
        for med_id, qty_needed in demand.items():
            available = self._med_inventory.get(med_id, 0)
            given = min(available, qty_needed)
            self._med_inventory[med_id] = available - given
            fulfilled[med_id] = given
            if given < qty_needed:
                stockout_count += 1
        return fulfilled, stockout_count

    def _compute_stockout_cost(
        self, demand: Dict[str, int], fulfilled: Dict[str, int]
    ) -> float:
        cost = 0.0
        for med_id, needed in demand.items():
            shortfall = needed - fulfilled.get(med_id, 0)
            if shortfall > 0:
                med = self._medications.get(med_id)
                if med:
                    cost += shortfall * med.stockout_penalty
        return cost

    # ── Staffing ──────────────────────────────────────────────────────────

    def _compute_staffing_ratios(self) -> Dict[str, float]:
        ratios: Dict[str, float] = {}
        for unit_id, unit in self._units.items():
            census = sum(1 for p in self._patients if p.unit_id == unit_id)
            if census == 0:
                ratios[unit_id] = 1.0
                continue
            sched = self._schedules.get(unit_id, {"doctors": 0, "nurses": 0, "techs": 0})
            required_nurses  = math.ceil(census * unit.min_nurse_ratio)
            required_doctors = math.ceil(census * unit.min_doctor_ratio)
            nurse_ratio  = sched.get("nurses", 0) / max(1, required_nurses)
            doctor_ratio = sched.get("doctors", 0) / max(1, required_doctors)
            ratios[unit_id] = min(nurse_ratio, doctor_ratio)
        return ratios

    def _count_understaffed(self) -> int:
        return sum(1 for r in self._compute_staffing_ratios().values() if r < 1.0)

    def _compute_med_supply_ratios(
        self, demand: Dict[str, int], fulfilled: Dict[str, int]
    ) -> Dict[str, float]:
        """Per-patient: ratio of their critical meds being met."""
        ratios: Dict[str, float] = {}
        for p in self._patients:
            total_needed = sum(p.meds_needed.values()) or 1
            total_got = sum(
                min(p.meds_needed.get(m, 0), fulfilled.get(m, 0))
                for m in p.meds_needed
            )
            ratios[p.id] = min(1.0, total_got / total_needed)
        return ratios

    # ── Patient outcomes ──────────────────────────────────────────────────

    def _process_patient_outcomes(
        self,
        staffing_ratios: Dict[str, float],
        med_supply_ratios: Dict[str, float],
    ) -> Tuple[int, int]:
        """Returns (mortality_count, deterioration_count)."""
        mortality, deteriorations = 0, 0
        survivors = []
        for p in self._patients:
            s_ratio = staffing_ratios.get(p.unit_id, 1.0)
            m_ratio = med_supply_ratios.get(p.id, 1.0)

            # Mortality check
            if self._simulator.compute_mortality(p, s_ratio, m_ratio):
                mortality += 1
                continue

            # Deterioration check
            worsened, new_acuity = self._simulator.compute_deterioration(
                p, s_ratio, m_ratio, self._day
            )
            if worsened:
                p.acuity = new_acuity
                p.deterioration_risk = min(0.95, p.deterioration_risk * 1.1)
                deteriorations += 1

            survivors.append(p)

        self._patients = survivors
        return mortality, deteriorations

    def _process_natural_discharges(self) -> int:
        remaining = []
        discharged = 0
        for p in self._patients:
            if not self._simulator.natural_discharge(p, self._day):
                remaining.append(p)
            else:
                discharged += 1
        self._patients = remaining
        return discharged

    # ── Costs & revenue ───────────────────────────────────────────────────

    def _compute_holding_cost(self) -> float:
        cost = 0.0
        for med_id, qty in self._med_inventory.items():
            med = self._medications.get(med_id)
            if med:
                cost += qty * med.holding_cost_per_day
        return cost

    def _compute_staffing_cost(self) -> float:
        # Already computed in _process_staffing; avoid double-count
        # Staffing cost is embedded in action_cost during _process_staffing
        return 0.0

    def _compute_revenue(
        self, demand: Dict[str, int], fulfilled: Dict[str, int]
    ) -> float:
        """Revenue per fulfilled patient-day (DRG-style)."""
        census = len(self._patients)
        return census * 350.0   # flat per-patient-day reimbursement

    # ── Reward ────────────────────────────────────────────────────────────

    def _compute_reward(self, daily: DailyMetrics, day_cost: float) -> float:
        weights = self._task_cfg.get("reward_weights", {})
        w_svc  = weights.get("service_level",  0.35)
        w_safe = weights.get("patient_safety", 0.35)
        w_cost = weights.get("cost_efficiency", 0.20)
        w_bed  = weights.get("bed_utilization", 0.10)

        # Service-level delta from previous day
        svc_score = daily.service_level * w_svc

        # Safety: mortality is bad
        safe_score = w_safe * (1.0 - min(1.0, daily.mortality_events / max(1, len(self._patients) + daily.mortality_events) * 20))

        # Cost: compare to daily budget (~revenue)
        budget = max(1.0, daily.total_revenue)
        cost_score = -w_cost * min(1.0, day_cost / budget)

        # Bed utilisation (optimal 0.75–0.95)
        util = daily.bed_utilization
        if 0.75 <= util <= 0.95:
            bed_score = w_bed
        elif util < 0.75:
            bed_score = w_bed * (util / 0.75)
        else:
            bed_score = w_bed * max(0, 1.0 - (util - 0.95) / 0.05)

        reward = svc_score + safe_score + cost_score + bed_score
        # Clip to [−1, +1]
        return max(-1.0, min(1.0, reward))

    # ── Build observation ─────────────────────────────────────────────────

    def _build_observation(self) -> Observation:
        bed_allocations = []
        for unit_id, unit in self._units.items():
            occupied = sum(1 for p in self._patients if p.unit_id == unit_id)
            reserved = max(0, unit.bed_capacity - occupied)
            bed_allocations.append(
                BedAllocation(
                    unit_id=unit_id,
                    occupied=occupied,
                    reserved=min(reserved, 3),
                    available=max(0, unit.bed_capacity - occupied - 3),
                )
            )

        total_occupied = sum(ba.occupied for ba in bed_allocations)
        total_capacity = sum(u.bed_capacity for u in self._units.values())
        overall_util = total_occupied / max(1, total_capacity)

        current_schedule = [
            StaffSchedule(
                unit_id=uid,
                day=self._day,
                doctors=sched.get("doctors", 0),
                nurses=sched.get("nurses", 0),
                techs=sched.get("techs", 0),
            )
            for uid, sched in self._schedules.items()
        ]

        # Build 3-day admission forecast
        forecasts = []
        if self._simulator:
            for unit_id in self._units:
                forecasts.extend(
                    self._simulator.forecast_admissions(self._day, unit_id, horizon=3)
                )

        service_level = (
            self._metrics_history[-1].service_level if self._metrics_history else 1.0
        )

        return Observation(
            day=self._day,
            episode_length=self._episode_length,
            task_id=self._task_id or "",
            patients=list(self._patients),
            bed_allocations=bed_allocations,
            med_inventory=dict(self._med_inventory),
            pending_med_orders=list(self._pending_orders),
            current_schedule=current_schedule,
            staff_pools=self._staff_pools,
            recent_metrics=self._metrics_history[-7:],
            cumulative_cost=round(self._cumulative_cost, 2),
            cumulative_revenue=round(self._cumulative_revenue, 2),
            cumulative_profit=round(self._cumulative_revenue - self._cumulative_cost, 2),
            cumulative_mortality=self._cumulative_mortality,
            cumulative_stockouts=self._cumulative_stockouts,
            expected_admissions=forecasts,
        )

    def _build_daily_metrics(
        self,
        admissions: int,
        discharges: int,
        transfers: int,
        mortality: int,
        stockouts: int,
        understaffed_shifts: int,
        med_demand: Dict[str, int],
        med_fulfilled: Dict[str, int],
        day_cost: float,
        revenue: float,
    ) -> DailyMetrics:
        total_demand = sum(med_demand.values())
        total_fulfilled = sum(med_fulfilled.values())
        service_level = total_fulfilled / max(1, total_demand)

        total_capacity = sum(u.bed_capacity for u in self._units.values())
        occupied = len(self._patients)
        bed_util = occupied / max(1, total_capacity)

        return DailyMetrics(
            day=self._day,
            admissions=admissions,
            discharges=discharges,
            transfers=transfers,
            mortality_events=mortality,
            stockout_incidents=stockouts,
            understaffed_shifts=understaffed_shifts,
            bed_utilization=round(bed_util, 3),
            service_level=round(service_level, 3),
            total_cost=round(day_cost, 2),
            total_revenue=round(revenue, 2),
            profit=round(revenue - day_cost, 2),
        )

    # ── Convenience ───────────────────────────────────────────────────────

    def available_tasks(self) -> List[str]:
        return list(ALL_TASKS.keys())

    def task_info(self, task_id: str) -> Dict:
        if task_id not in ALL_TASKS:
            raise ValueError(f"Unknown task: {task_id}")
        t = ALL_TASKS[task_id]
        return {
            "task_id": t["task_id"],
            "difficulty": t["difficulty"],
            "episode_length": t["episode_length"],
            "scenario": t.get("scenario", "normal"),
            "description": t["description"],
            "n_units": len(t["units"]),
            "n_medications": len(t["medications"]),
        }
