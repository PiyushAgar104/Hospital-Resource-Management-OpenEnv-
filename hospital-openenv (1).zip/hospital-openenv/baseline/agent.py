"""
Baseline agents for the Hospital Resource Management OpenEnv.

Three agents of increasing sophistication:
  1. RandomAgent      – random valid actions (lower bound)
  2. HeuristicAgent   – rule-based reorder-point + staffing ratios (baseline)
  3. GreedyAgent      – forward-looking greedy using 3-day forecast (strong baseline)
"""
from __future__ import annotations

import math
import random
from typing import Dict, List, Optional

from environment.models import (
    AgentAction,
    BedTransferAction,
    DischargeAction,
    EnvConfig,
    MedOrderAction,
    Observation,
    PatientAcuity,
    StaffAssignAction,
)


# ─── Random Agent ─────────────────────────────────────────────────────────────

class RandomAgent:
    """Chooses uniformly random valid actions. Used as lower-bound baseline."""

    def __init__(self, seed: int = 0) -> None:
        self.rng = random.Random(seed)

    def act(self, obs: Observation, cfg: EnvConfig) -> AgentAction:
        meds = [m.id for m in cfg.medications]
        units = [u.id for u in cfg.units]

        med_orders = []
        for med_id in meds:
            if self.rng.random() < 0.3:
                qty = self.rng.randint(10, 200)
                med_orders.append(MedOrderAction(med_id=med_id, quantity=qty))

        staff_assign = []
        for uid in units:
            staff_assign.append(
                StaffAssignAction(
                    unit_id=uid,
                    doctors=self.rng.randint(1, 6),
                    nurses=self.rng.randint(3, 15),
                    techs=self.rng.randint(1, 6),
                )
            )

        return AgentAction(med_orders=med_orders, staff_assign=staff_assign)


# ─── Heuristic Agent ─────────────────────────────────────────────────────────

class HeuristicAgent:
    """
    Rule-based agent implementing classic inventory management:

    Medications:
      - Reorder when inventory < (lead_time + safety_stock) × expected_daily_demand
      - Order up to (target_days × expected_demand) – (on_hand + on_order)
      - Rush if critically low (< 2 days supply)

    Staffing:
      - Compute required staff from current census × min ratios × safety factor (1.2)
      - Distribute remaining pool proportionally to acuity-weighted census

    Transfers:
      - Move CRITICAL patients to ICU if beds available
      - Move LOW patients from ICU/Surgery to General if unit full
    """

    TARGET_DAYS = 10   # days of supply to hold
    SAFETY_FACTOR = 1.2
    RUSH_THRESHOLD_DAYS = 2

    def __init__(self) -> None:
        self._med_catalog: Dict = {}
        self._unit_catalog: Dict = {}

    def act(self, obs: Observation, cfg: EnvConfig) -> AgentAction:
        self._med_catalog = {m.id: m for m in cfg.medications}
        self._unit_catalog = {u.id: u for u in cfg.units}

        med_orders  = self._decide_orders(obs)
        staff_assign = self._decide_staffing(obs)
        transfers   = self._decide_transfers(obs)
        discharges  = self._decide_discharges(obs)

        return AgentAction(
            med_orders=med_orders,
            staff_assign=staff_assign,
            bed_transfers=transfers,
            discharges=discharges,
        )

    # ── Ordering ──────────────────────────────────────────────────────────

    def _decide_orders(self, obs: Observation) -> List[MedOrderAction]:
        # Estimate daily demand per medication from patient census
        estimated_demand = self._estimate_daily_demand(obs)
        on_order: Dict[str, int] = {}
        for po in obs.pending_med_orders:
            on_order[po.med_id] = on_order.get(po.med_id, 0) + po.quantity

        orders = []
        for med_id, med in self._med_catalog.items():
            daily_demand = estimated_demand.get(med_id, 0)
            if daily_demand == 0:
                daily_demand = 1   # small buffer even if no current demand

            on_hand = obs.med_inventory.get(med_id, 0)
            in_transit = on_order.get(med_id, 0)
            total_coverage = on_hand + in_transit

            safety_stock = math.ceil(daily_demand * med.lead_time_days * self.SAFETY_FACTOR)
            reorder_point = safety_stock + math.ceil(daily_demand * med.lead_time_days)
            target_qty    = math.ceil(daily_demand * self.TARGET_DAYS)

            if total_coverage <= reorder_point:
                order_qty = max(0, target_qty - total_coverage)
                order_qty = min(order_qty, med.max_order_qty)
                if order_qty > 0:
                    rush = (on_hand < daily_demand * self.RUSH_THRESHOLD_DAYS)
                    orders.append(MedOrderAction(
                        med_id=med_id,
                        quantity=order_qty,
                        rush=rush,
                    ))
        return orders

    def _estimate_daily_demand(self, obs: Observation) -> Dict[str, float]:
        """Sum up each patient's daily med needs."""
        demand: Dict[str, float] = {}
        for p in obs.patients:
            for med_id, qty in p.meds_needed.items():
                demand[med_id] = demand.get(med_id, 0.0) + qty
        return demand

    # ── Staffing ──────────────────────────────────────────────────────────

    def _decide_staffing(self, obs: Observation) -> List[StaffAssignAction]:
        assigns = []
        # Available pool
        pool_map: Dict[str, int] = {}
        for pool in obs.staff_pools:
            pool_map[pool.role.value] = pool.available

        for sched in obs.current_schedule:
            unit = self._unit_catalog.get(sched.unit_id)
            if not unit:
                continue
            census = sum(1 for p in obs.patients if p.unit_id == sched.unit_id)
            # Acuity weighting: CRITICAL patients need 1.5× staff
            acuity_weight = 1.0
            unit_patients = [p for p in obs.patients if p.unit_id == sched.unit_id]
            if unit_patients:
                crit_frac = sum(1 for p in unit_patients if p.acuity == PatientAcuity.CRITICAL) / len(unit_patients)
                acuity_weight = 1.0 + 0.5 * crit_frac

            req_doctors = math.ceil(census * unit.min_doctor_ratio * acuity_weight * self.SAFETY_FACTOR)
            req_nurses  = math.ceil(census * unit.min_nurse_ratio  * acuity_weight * self.SAFETY_FACTOR)
            req_techs   = max(1, math.ceil(census * 0.05 * self.SAFETY_FACTOR))

            assigns.append(StaffAssignAction(
                unit_id=sched.unit_id,
                doctors=min(req_doctors, pool_map.get("doctor", 99)),
                nurses=min(req_nurses,  pool_map.get("nurse", 99)),
                techs=min(req_techs,    pool_map.get("technician", 99)),
            ))
        return assigns

    # ── Transfers ─────────────────────────────────────────────────────────

    def _decide_transfers(self, obs: Observation) -> List[BedTransferAction]:
        transfers = []
        icu_units = [uid for uid, u in self._unit_catalog.items() if u.unit_type.value == "icu"]
        gen_units = [uid for uid, u in self._unit_catalog.items() if u.unit_type.value == "general"]

        if not icu_units:
            return []

        icu_id = icu_units[0]
        icu_unit = self._unit_catalog[icu_id]
        icu_census = sum(1 for p in obs.patients if p.unit_id == icu_id)
        icu_available = icu_unit.bed_capacity - icu_census

        # Move CRITICAL patients to ICU if space
        for p in obs.patients:
            if p.acuity == PatientAcuity.CRITICAL and p.unit_id != icu_id and icu_available > 0:
                transfers.append(BedTransferAction(patient_id=p.id, to_unit_id=icu_id))
                icu_available -= 1
                if len(transfers) >= 3:
                    break

        # Move LOW-acuity ICU patients to general if ICU is crowded
        if icu_available < 2 and gen_units:
            gen_id = gen_units[0]
            gen_unit = self._unit_catalog[gen_id]
            gen_census = sum(1 for p in obs.patients if p.unit_id == gen_id)
            if gen_census < gen_unit.bed_capacity:
                for p in obs.patients:
                    if p.unit_id == icu_id and p.acuity == PatientAcuity.LOW:
                        transfers.append(BedTransferAction(patient_id=p.id, to_unit_id=gen_id))
                        if len(transfers) >= 5:
                            break

        return transfers

    # ── Discharges ────────────────────────────────────────────────────────

    def _decide_discharges(self, obs: Observation) -> List[DischargeAction]:
        discharges = []
        for p in obs.patients:
            if p.acuity == PatientAcuity.LOW:
                los = obs.day - p.admission_day
                if los >= p.expected_los:
                    discharges.append(DischargeAction(patient_id=p.id))
                    if len(discharges) >= 5:
                        break
        return discharges


# ─── Greedy Agent ─────────────────────────────────────────────────────────────

class GreedyAgent(HeuristicAgent):
    """
    Extended heuristic that uses the 3-day admission forecast to pre-order
    medications and pre-staff ahead of anticipated surges.
    """

    SURGE_BUFFER = 1.4   # pre-order 40% extra if forecast shows surge

    def act(self, obs: Observation, cfg: EnvConfig) -> AgentAction:
        self._med_catalog = {m.id: m for m in cfg.medications}
        self._unit_catalog = {u.id: u for u in cfg.units}

        base_action = super().act(obs, cfg)

        # Augment orders based on forecast
        forecast_demand = self._forecast_demand(obs)
        augmented_orders = self._augment_orders(obs, base_action.med_orders, forecast_demand)

        # Augment staffing based on forecast census
        forecast_census = self._forecast_census(obs)
        augmented_staff = self._augment_staffing(obs, base_action.staff_assign, forecast_census)

        return AgentAction(
            med_orders=augmented_orders,
            staff_assign=augmented_staff,
            bed_transfers=base_action.bed_transfers,
            discharges=base_action.discharges,
        )

    def _forecast_demand(self, obs: Observation) -> Dict[str, float]:
        """Estimate next 3 days' med demand from forecast admissions."""
        demand: Dict[str, float] = {}
        for fc in obs.expected_admissions:
            count = fc.get("expected_count", 0)
            if count <= 0:
                continue
            # Rough avg demand per patient per day
            for med_id in self._med_catalog:
                demand[med_id] = demand.get(med_id, 0) + count * 1.5
        return demand

    def _augment_orders(
        self,
        obs: Observation,
        base_orders: List[MedOrderAction],
        forecast: Dict[str, float],
    ) -> List[MedOrderAction]:
        existing = {o.med_id for o in base_orders}
        orders = list(base_orders)
        for med_id, fcast_demand in forecast.items():
            if med_id in existing:
                continue
            med = self._med_catalog.get(med_id)
            if not med:
                continue
            on_hand = obs.med_inventory.get(med_id, 0)
            target = math.ceil(fcast_demand * self.SURGE_BUFFER * 3)
            if on_hand < target:
                qty = min(target - on_hand, med.max_order_qty)
                if qty > 0:
                    orders.append(MedOrderAction(med_id=med_id, quantity=qty))
        return orders

    def _forecast_census(self, obs: Observation) -> Dict[str, float]:
        future: Dict[str, float] = {}
        for fc in obs.expected_admissions:
            uid = fc.get("unit_id", "")
            future[uid] = future.get(uid, 0) + fc.get("expected_count", 0)
        return future

    def _augment_staffing(
        self,
        obs: Observation,
        base_assigns: List[StaffAssignAction],
        forecast_census: Dict[str, float],
    ) -> List[StaffAssignAction]:
        assign_map = {a.unit_id: a for a in base_assigns}
        result = []
        for uid, unit in self._unit_catalog.items():
            base = assign_map.get(uid)
            extra_census = forecast_census.get(uid, 0)
            extra_nurses  = math.ceil(extra_census * unit.min_nurse_ratio  * self.SURGE_BUFFER)
            extra_doctors = math.ceil(extra_census * unit.min_doctor_ratio * self.SURGE_BUFFER)

            if base:
                result.append(StaffAssignAction(
                    unit_id=uid,
                    doctors=base.doctors + extra_doctors,
                    nurses=base.nurses + extra_nurses,
                    techs=base.techs,
                ))
            else:
                result.append(StaffAssignAction(
                    unit_id=uid,
                    doctors=extra_doctors,
                    nurses=extra_nurses,
                    techs=1,
                ))
        return result
