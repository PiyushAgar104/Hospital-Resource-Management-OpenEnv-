# Architecture Guide

This document explains how the environment is structured internally so you can extend it confidently.

---

## High-level flow

```
Agent
  │
  │  action: AgentAction
  ▼
HospitalEnv.step()
  │
  ├── 1. Apply crisis events (Task 3 only)
  ├── 2. Receive pending medication deliveries
  ├── 3. Process agent actions
  │     ├── med_orders    → create PendingMedOrder entries
  │     ├── staff_assign  → update schedule dict
  │     ├── bed_transfers → move patients between units
  │     └── discharges    → remove patients, earn revenue
  ├── 4. DemandSimulator.generate_admissions() → new Patient objects
  ├── 5. DemandSimulator.compute_daily_med_demand() → {med_id: units}
  ├── 6. Fulfil med demand from inventory → compute stockout cost
  ├── 7. Compute staffing ratios per unit
  ├── 8. DemandSimulator.compute_deterioration/mortality() per patient
  ├── 9. DemandSimulator.natural_discharge() per patient
  ├── 10. Compute daily costs (holding + staffing + stockout)
  ├── 11. Build DailyMetrics
  ├── 12. Compute shaped reward
  └── 13. Return StepResult(observation, reward, done, info)
```

---

## Module responsibilities

### `environment/models.py`

Pure data — no logic. Every class is a Python `dataclass` with a `.model_dump()` method for JSON serialisation. No external dependencies.

Key classes:

| Class | Role |
|-------|------|
| `Patient` | One admitted patient; carries acuity, LOS, per-day med needs, deterioration risk |
| `AgentAction` | Everything the agent submits for one day |
| `Observation` | Complete environment state returned each step |
| `DailyMetrics` | Per-day KPI snapshot kept in history |
| `EpisodeScore` | Final graded result with breakdown |

### `environment/simulator/demand.py`

All stochastic logic lives here. Stateless given an RNG seed.

- `generate_admissions()` — Poisson arrivals with day-of-week + seasonal + scenario multipliers
- `compute_daily_med_demand()` — aggregate per-patient consumption with 15% daily noise
- `compute_deterioration()` — risk = base × fatigue × (2 − staffing_ratio) × (1 + 3 × med_shortfall)
- `compute_mortality()` — critical patients only; risk capped at 40%
- `natural_discharge()` — probabilistic after expected LOS
- `forecast_admissions()` — noisy ±30% 3-day-ahead forecast

### `environment/tasks/tasks.py`

Static configuration dicts. Each task specifies:
- `units` — list of `HospitalUnit` (id, type, capacity, staffing ratios)
- `medications` — from the shared catalog (unit cost, lead time, stockout penalty, criticality)
- `staff_pools` — doctor / nurse / tech pool sizes and shift costs
- `initial_inventory` and `initial_staff_schedule`
- `reward_weights` — how the 4–5 criteria are weighted
- `crisis_events` — list of timed events (Task 3 only)

### `environment/graders/graders.py`

Episode-level scoring. Each grader:
1. Computes 4–5 sub-scores from `List[DailyMetrics]`
2. Weights them into a scalar `score ∈ [0.0, 1.0]`
3. Returns `EpisodeScore` with full breakdown and human-readable notes

Sub-score functions are shared across all graders (`_service_level_score`, `_mortality_score`, etc.) so adding a new task just requires a new `WEIGHTS` dict and any task-specific adjustments.

### `environment/env.py`

Orchestrates everything. Holds all mutable state:

```python
self._patients: List[Patient]
self._med_inventory: Dict[str, int]
self._pending_orders: List[PendingMedOrder]
self._schedules: Dict[str, Dict[str, int]]   # unit_id → {role: count}
self._metrics_history: List[DailyMetrics]
```

Key design decisions:
- **Single-instance, single-episode** — call `reset()` to start a new episode
- **No global state** — multiple `HospitalEnv()` instances are fully independent
- **Deterministic given seed** — `reset(seed=42)` always produces identical episode trajectories

---

## Reward shaping details

```
reward = w_svc  × service_level_today
       + w_safe × (1 − mortality_rate_today × 20)
       − w_cost × min(1.0, day_cost / max(1, revenue_today))
       + w_bed  × bed_util_score
```

`bed_util_score`:
- 1.0 if utilisation ∈ [0.75, 0.95]
- Linear ramp up to 0.75
- Linear decay above 0.95 (overcrowding penalty)

The reward is clipped to `[−1.0, +1.0]` before returning. A terminal bonus of `+0.5` is added to the final step's reward if the graded episode score ≥ 0.80.

---

## Crisis event system

Crisis events are declared in the task config as a list of dicts:

```python
{"day": 30, "type": "staff_strike",       "pool_reduction": 0.40, "duration": 6}
{"day": 15, "type": "supply_disruption",  "med_id": "vancomycin", "duration": 5}
{"day": 60, "type": "mass_casualty",      "extra_arrivals": 30,   "unit": "emergency"}
```

`env._apply_crisis_events()` fires on each `step()`. Supply disruptions add the `med_id` to `self._active_supply_blocks` for `duration` days — during which standard orders for that medication are rejected (agent must use `rush=True`). Staff strikes reduce effective pool capacity by `pool_reduction` for `duration` days.

---

## Adding a gymnasium wrapper

```python
import gymnasium as gym
import numpy as np
from environment import HospitalEnv, AgentAction

class HospitalGymEnv(gym.Env):
    metadata = {"render_modes": []}

    def __init__(self, task_id="task1_single_ward"):
        super().__init__()
        self._env = HospitalEnv()
        self._task_id = task_id
        self._cfg = None
        # Define spaces (use Dict or flatten as needed)
        self.observation_space = gym.spaces.Dict({})   # TODO: define per task
        self.action_space = gym.spaces.Dict({})         # TODO: define per task

    def reset(self, seed=None, options=None):
        obs, self._cfg = self._env.reset(self._task_id, seed=seed)
        return obs, {}

    def step(self, action: AgentAction):
        result = self._env.step(action)
        return result.observation, result.reward, result.done, result.truncated, result.info

    def render(self): pass
    def close(self): pass
```
