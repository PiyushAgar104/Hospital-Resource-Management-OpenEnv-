# Contributing to Hospital Resource Management OpenEnv

Thank you for your interest in contributing! This guide covers everything you need to get started.

---

## Table of contents

- [Code of conduct](#code-of-conduct)
- [Ways to contribute](#ways-to-contribute)
- [Development setup](#development-setup)
- [Project structure](#project-structure)
- [Running tests](#running-tests)
- [Adding a new task](#adding-a-new-task)
- [Adding a new agent](#adding-a-new-agent)
- [Submitting a pull request](#submitting-a-pull-request)
- [Coding standards](#coding-standards)

---

## Code of conduct

Be respectful and constructive. We welcome contributors of all backgrounds and experience levels.

---

## Ways to contribute

| Type | Examples |
|------|---------|
| Bug fixes | Wrong reward value, simulation logic errors, test failures |
| New tasks | New hospital scenarios (e.g. paediatric ward, rural clinic) |
| New agents | RL agents, LLM-based agents, better heuristics |
| Documentation | Improve README, add docstrings, fix typos |
| Benchmarks | Add reproducible scores for new agents |
| Integrations | Gymnasium wrapper, RLlib adapter, SB3 example |

---

## Development setup

### Requirements

- Python 3.10 or later
- numpy (already installed on most systems)
- No other dependencies for the core environment

```bash
# 1. Fork and clone
git clone https://github.com/YOUR-USERNAME/hospital-openenv.git
cd hospital-openenv

# 2. (Optional) create a virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 3. Install optional extras (only needed for app.py / HF Spaces)
pip install -r requirements.txt

# 4. Verify everything works
python -m unittest tests.test_env -v
```

Expected output: `Ran 60 tests in ~1s — OK`

---

## Project structure

```
hospital-openenv/
├── environment/
│   ├── models.py        ← All dataclass types (edit here to add fields)
│   ├── env.py           ← HospitalEnv core logic (step/reset/state/score)
│   ├── simulator/
│   │   └── demand.py    ← Stochastic patient flow simulation
│   ├── tasks/
│   │   └── tasks.py     ← Task 1/2/3 definitions (add new tasks here)
│   └── graders/
│       └── graders.py   ← Episode graders — scores 0.0 to 1.0
├── baseline/
│   ├── agent.py         ← Random / Heuristic / Greedy agents
│   └── run_baseline.py  ← Reproducible evaluation script
├── tests/
│   └── test_env.py      ← 60 unittest tests
├── server.py            ← stdlib HTTP server (zero deps)
├── app.py               ← FastAPI + Gradio (HF Spaces)
├── openenv.yaml         ← OpenEnv 1.0 specification
└── Dockerfile
```

---

## Running tests

```bash
# Run all tests
python -m unittest tests.test_env -v

# Run a specific test class
python -m unittest tests.test_env.TestStepAPI -v

# Run a single test
python -m unittest tests.test_env.TestGraders.test_perfect_task1_gets_high_score -v
```

All 60 tests must pass before submitting a pull request.

---

## Adding a new task

1. Open `environment/tasks/tasks.py`
2. Create a new dict following the existing pattern:

```python
TASK4 = {
    "task_id":         "task4_my_scenario",
    "difficulty":      "medium",
    "episode_length":  45,
    "scenario":        "normal",          # or "surge" / "epidemic"
    "seed":            777,
    "description":     "One sentence describing the clinical scenario.",
    "units":           [...],             # list of HospitalUnit
    "medications":     _make_medications([...]),
    "staff_pools":     _make_staff_pools(scale=1.0),
    "initial_inventory":      {...},
    "initial_staff_schedule": {...},
    "reward_weights":  {
        "service_level":   0.30,
        "patient_safety":  0.35,
        "cost_efficiency": 0.20,
        "bed_utilization": 0.15,
    },
    "action_space_description":      {...},
    "observation_space_description": {...},
}
ALL_TASKS["task4_my_scenario"] = TASK4
```

3. Add a grader in `environment/graders/graders.py`:

```python
class Task4Grader:
    WEIGHTS = {...}
    BENCHMARK_CPP = 2_000.0

    def grade(self, metrics, total_patients, extra=None):
        breakdown = {
            "service_level":   _service_level_score(metrics),
            "patient_safety":  _mortality_score(metrics, total_patients),
            "cost_efficiency": _cost_efficiency_score(metrics, total_patients, self.BENCHMARK_CPP),
            "bed_utilization": _bed_utilization_score(metrics),
        }
        score = sum(breakdown[k] * v for k, v in self.WEIGHTS.items())
        return EpisodeScore(
            task_id="task4_my_scenario",
            score=round(max(0.0, min(1.0, score)), 4),
            grade=_letter_grade(score),
            metrics={},
            breakdown=breakdown,
            notes="",
        )

GRADERS["task4_my_scenario"] = Task4Grader()
```

4. Add tests in `tests/test_env.py` and update `openenv.yaml`.

---

## Adding a new agent

Create a class with a single `act(obs, cfg)` method that returns an `AgentAction`:

```python
# baseline/agent.py  (or your own file)
from environment.models import AgentAction, MedOrderAction, StaffAssignAction

class MyAgent:
    def act(self, obs, cfg):
        # obs: Observation dataclass
        # cfg: EnvConfig dataclass (static, use for unit/med catalog)
        return AgentAction(
            med_orders   = [...],
            staff_assign = [...],
            bed_transfers = [],
            discharges    = [],
        )
```

Then benchmark it:

```python
# Add to baseline/run_baseline.py AGENTS dict
AGENTS["my_agent"] = MyAgent

# Run
python -m baseline.run_baseline --agent my_agent --seeds 5 --json
```

Include `baseline/expected_scores.json` updates in your pull request.

---

## Submitting a pull request

1. Create a branch: `git checkout -b feat/my-new-task`
2. Make your changes
3. Ensure all 60 tests still pass: `python -m unittest tests.test_env -v`
4. Add tests for any new functionality
5. Update `CHANGELOG.md` under `[Unreleased]`
6. Push and open a pull request against `main`

### Pull request checklist

- [ ] All existing tests pass
- [ ] New functionality has tests
- [ ] `openenv.yaml` updated if tasks/API changed
- [ ] `CHANGELOG.md` updated
- [ ] Docstrings added for new public methods
- [ ] No new external dependencies added to core `environment/`

---

## Coding standards

- **Python 3.10+** — use `match`, `|` union types, `from __future__ import annotations`
- **Type hints** on all public functions and methods
- **Docstrings** on all public classes and methods (single-line or Google style)
- **Naming**: `snake_case` for functions/variables, `PascalCase` for classes, `UPPER_SNAKE` for module-level constants
- **No external deps** in `environment/` or `baseline/` — stdlib + numpy only
- **Line length**: 100 characters max
- **Imports**: stdlib → third-party → local, separated by blank lines

```python
# Good
def compute_reward(daily: DailyMetrics, day_cost: float) -> float:
    """Compute the shaped step reward clipped to [−1, +1]."""
    ...

# Bad — no type hints, no docstring
def reward(m, c):
    ...
```

---

## Questions?

Open a GitHub Discussion or file an issue tagged `question`. We aim to respond within 48 hours.
