"""
Task definitions for the Hospital Resource Management OpenEnv.

Task 1 (Easy)   – Single ward, 30 days, basic inventory + staffing
Task 2 (Medium) – Multi-ward, 60 days, full med ordering + transfers
Task 3 (Hard)   – Multi-ward surge scenario, 90 days, crisis management
"""
from __future__ import annotations

from typing import Dict, List

from environment.models import (
    HospitalUnit,
    MedCategory,
    Medication,
    StaffPool,
    StaffRole,
    UnitType,
)


# ─────────────────────────────────────────────────────────────────────────────
#  Shared catalog helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_medications(ids: List[str]) -> List[Medication]:
    catalog: Dict[str, Medication] = {
        "amoxicillin": Medication(
            id="amoxicillin", name="Amoxicillin 500mg",
            category=MedCategory.ANTIBIOTIC,
            unit_cost=1.20, holding_cost_per_day=0.02,
            stockout_penalty=50.0, lead_time_days=2,
            shelf_life_days=90, max_order_qty=2000,
        ),
        "vancomycin": Medication(
            id="vancomycin", name="Vancomycin IV",
            category=MedCategory.ANTIBIOTIC,
            unit_cost=8.50, holding_cost_per_day=0.10,
            stockout_penalty=200.0, lead_time_days=3,
            shelf_life_days=60, max_order_qty=500,
            critical=True,
        ),
        "morphine": Medication(
            id="morphine", name="Morphine 10mg/mL",
            category=MedCategory.ANALGESIC,
            unit_cost=4.00, holding_cost_per_day=0.06,
            stockout_penalty=100.0, lead_time_days=1,
            shelf_life_days=30, max_order_qty=1000,
            critical=True,
        ),
        "ibuprofen": Medication(
            id="ibuprofen", name="Ibuprofen 400mg",
            category=MedCategory.ANALGESIC,
            unit_cost=0.30, holding_cost_per_day=0.005,
            stockout_penalty=15.0, lead_time_days=1,
            shelf_life_days=180, max_order_qty=5000,
        ),
        "digoxin": Medication(
            id="digoxin", name="Digoxin 0.25mg",
            category=MedCategory.CARDIAC,
            unit_cost=3.50, holding_cost_per_day=0.05,
            stockout_penalty=300.0, lead_time_days=2,
            shelf_life_days=120, max_order_qty=300,
            critical=True,
        ),
        "metoprolol": Medication(
            id="metoprolol", name="Metoprolol 50mg",
            category=MedCategory.CARDIAC,
            unit_cost=0.80, holding_cost_per_day=0.01,
            stockout_penalty=80.0, lead_time_days=2,
            shelf_life_days=150, max_order_qty=1000,
        ),
        "midazolam": Medication(
            id="midazolam", name="Midazolam 5mg/mL",
            category=MedCategory.SEDATIVE,
            unit_cost=12.00, holding_cost_per_day=0.18,
            stockout_penalty=250.0, lead_time_days=2,
            shelf_life_days=45, max_order_qty=200,
            critical=True,
        ),
        "packed_rbc": Medication(
            id="packed_rbc", name="Packed Red Blood Cells",
            category=MedCategory.BLOOD_PRODUCT,
            unit_cost=250.0, holding_cost_per_day=5.00,
            stockout_penalty=1000.0, lead_time_days=1,
            shelf_life_days=42, max_order_qty=50,
            critical=True,
        ),
    }
    return [catalog[i] for i in ids if i in catalog]


def _make_staff_pools(scale: float = 1.0) -> List[StaffPool]:
    return [
        StaffPool(role=StaffRole.DOCTOR,  available=int(30 * scale), daily_cost=800.0, overtime_cost=400.0),
        StaffPool(role=StaffRole.NURSE,   available=int(80 * scale), daily_cost=320.0, overtime_cost=160.0),
        StaffPool(role=StaffRole.TECH,    available=int(40 * scale), daily_cost=200.0, overtime_cost=100.0),
    ]


# ─────────────────────────────────────────────────────────────────────────────
#  Task 1 – Easy: Single ward, basic ops
# ─────────────────────────────────────────────────────────────────────────────

TASK1 = {
    "task_id": "task1_single_ward",
    "difficulty": "easy",
    "episode_length": 30,
    "scenario": "normal",
    "seed": 42,
    "description": (
        "Manage a single General Ward for 30 days. "
        "Keep patients supplied with medications and ensure adequate staffing. "
        "Minimize stockouts and patient deterioration."
    ),
    "units": [
        HospitalUnit(
            id="gen_ward",
            name="General Ward A",
            unit_type=UnitType.GENERAL,
            bed_capacity=30,
            min_nurse_ratio=0.25,   # 1 nurse per 4 beds
            min_doctor_ratio=0.08,  # 1 doctor per 12 beds
        )
    ],
    "medications": _make_medications(["amoxicillin", "ibuprofen", "morphine", "metoprolol"]),
    "staff_pools": _make_staff_pools(scale=0.4),
    "initial_inventory": {
        "amoxicillin": 200,
        "ibuprofen": 500,
        "morphine": 80,
        "metoprolol": 150,
    },
    "initial_staff_schedule": {
        "gen_ward": {"doctors": 3, "nurses": 8, "techs": 4}
    },
    "reward_weights": {
        "service_level": 0.35,
        "patient_safety": 0.35,
        "cost_efficiency": 0.20,
        "bed_utilization": 0.10,
    },
    "action_space_description": {
        "med_orders": "Order 1–4 medications per day (no rush option)",
        "staff_assign": "Adjust staffing for gen_ward (doctors 2–8, nurses 5–20)",
        "bed_transfers": "Not applicable (single ward)",
        "discharges": "Discharge stable LOW-acuity patients early",
    },
    "observation_space_description": {
        "patients": "Current patient list with acuity and med needs",
        "med_inventory": "Stock levels for 4 medications",
        "pending_med_orders": "Incoming deliveries",
        "current_schedule": "Today's staffing",
        "recent_metrics": "Last 7 days of KPIs",
        "expected_admissions": "Noisy 3-day forecast",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
#  Task 2 – Medium: Multi-ward, 60 days
# ─────────────────────────────────────────────────────────────────────────────

TASK2 = {
    "task_id": "task2_multi_ward",
    "difficulty": "medium",
    "episode_length": 60,
    "scenario": "normal",
    "seed": 123,
    "description": (
        "Manage an Emergency Department, General Ward, and ICU simultaneously "
        "for 60 days. Coordinate medication ordering across 8 drug types, "
        "manage staff across units, and transfer patients between wards as "
        "their acuity changes."
    ),
    "units": [
        HospitalUnit(
            id="emergency",
            name="Emergency Department",
            unit_type=UnitType.EMERGENCY,
            bed_capacity=20,
            min_nurse_ratio=0.50,
            min_doctor_ratio=0.15,
        ),
        HospitalUnit(
            id="gen_ward",
            name="General Ward B",
            unit_type=UnitType.GENERAL,
            bed_capacity=40,
            min_nurse_ratio=0.25,
            min_doctor_ratio=0.08,
        ),
        HospitalUnit(
            id="icu",
            name="Intensive Care Unit",
            unit_type=UnitType.ICU,
            bed_capacity=12,
            min_nurse_ratio=1.00,   # 1:1 nursing
            min_doctor_ratio=0.25,
        ),
    ],
    "medications": _make_medications([
        "amoxicillin", "vancomycin", "morphine", "ibuprofen",
        "digoxin", "metoprolol", "midazolam", "packed_rbc",
    ]),
    "staff_pools": _make_staff_pools(scale=1.0),
    "initial_inventory": {
        "amoxicillin": 400,
        "vancomycin": 100,
        "morphine": 150,
        "ibuprofen": 800,
        "digoxin": 60,
        "metoprolol": 200,
        "midazolam": 40,
        "packed_rbc": 10,
    },
    "initial_staff_schedule": {
        "emergency": {"doctors": 4, "nurses": 10, "techs": 4},
        "gen_ward":  {"doctors": 4, "nurses": 12, "techs": 5},
        "icu":       {"doctors": 3, "nurses": 12, "techs": 4},
    },
    "reward_weights": {
        "service_level":   0.30,
        "patient_safety":  0.30,
        "cost_efficiency": 0.20,
        "bed_utilization": 0.10,
        "transfer_timing": 0.10,
    },
    "action_space_description": {
        "med_orders":    "Order any of 8 medications, with optional rush delivery",
        "staff_assign":  "Assign doctors/nurses/techs to 3 units independently",
        "bed_transfers": "Transfer patients to more appropriate acuity unit",
        "discharges":    "Discharge stable patients to free beds",
    },
    "observation_space_description": {
        "patients":             "All patients across 3 units",
        "med_inventory":        "8 medication stock levels",
        "pending_med_orders":   "Incoming deliveries with ETA",
        "current_schedule":     "Per-unit staffing",
        "recent_metrics":       "7-day KPI history",
        "expected_admissions":  "3-day forecast per unit and acuity tier",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
#  Task 3 – Hard: Surge crisis, 90 days
# ─────────────────────────────────────────────────────────────────────────────

TASK3 = {
    "task_id": "task3_surge_crisis",
    "difficulty": "hard",
    "episode_length": 90,
    "scenario": "surge",   # 1.6× arrival rate
    "seed": 999,
    "description": (
        "Manage a 4-unit hospital network (Emergency, General, Surgery, ICU) "
        "during a patient surge lasting 90 days. Arrivals are 60% above normal; "
        "critical medication shortages are pre-injected on days 15 and 45; "
        "a staff strike is simulated on days 30–35 reducing pool availability by 40%. "
        "Achieve a service level ≥ 0.85, mortality rate < 2%, and cost-per-patient < $3,000 "
        "while managing the crisis."
    ),
    "units": [
        HospitalUnit(
            id="emergency",
            name="Emergency Department",
            unit_type=UnitType.EMERGENCY,
            bed_capacity=25,
            min_nurse_ratio=0.50,
            min_doctor_ratio=0.15,
        ),
        HospitalUnit(
            id="gen_ward",
            name="General Ward C",
            unit_type=UnitType.GENERAL,
            bed_capacity=50,
            min_nurse_ratio=0.25,
            min_doctor_ratio=0.08,
        ),
        HospitalUnit(
            id="surgery",
            name="Surgical Unit",
            unit_type=UnitType.SURGERY,
            bed_capacity=20,
            min_nurse_ratio=0.50,
            min_doctor_ratio=0.20,
        ),
        HospitalUnit(
            id="icu",
            name="Intensive Care Unit",
            unit_type=UnitType.ICU,
            bed_capacity=16,
            min_nurse_ratio=1.00,
            min_doctor_ratio=0.25,
        ),
    ],
    "medications": _make_medications([
        "amoxicillin", "vancomycin", "morphine", "ibuprofen",
        "digoxin", "metoprolol", "midazolam", "packed_rbc",
    ]),
    "staff_pools": _make_staff_pools(scale=1.5),
    "initial_inventory": {
        "amoxicillin": 300,    # intentionally low for challenge
        "vancomycin": 50,
        "morphine": 100,
        "ibuprofen": 600,
        "digoxin": 40,
        "metoprolol": 120,
        "midazolam": 25,
        "packed_rbc": 8,
    },
    # Crisis events injected by the environment
    "crisis_events": [
        {"day": 15, "type": "supply_disruption", "med_id": "vancomycin", "duration": 5},
        {"day": 15, "type": "supply_disruption", "med_id": "midazolam",  "duration": 3},
        {"day": 30, "type": "staff_strike",       "pool_reduction": 0.40, "duration": 6},
        {"day": 45, "type": "supply_disruption", "med_id": "packed_rbc", "duration": 4},
        {"day": 60, "type": "mass_casualty",      "extra_arrivals": 30,   "unit": "emergency"},
    ],
    "initial_staff_schedule": {
        "emergency": {"doctors": 5, "nurses": 13, "techs": 6},
        "gen_ward":  {"doctors": 5, "nurses": 14, "techs": 7},
        "surgery":   {"doctors": 4, "nurses": 10, "techs": 5},
        "icu":       {"doctors": 4, "nurses": 16, "techs": 6},
    },
    "reward_weights": {
        "service_level":   0.25,
        "patient_safety":  0.35,
        "cost_efficiency": 0.15,
        "bed_utilization": 0.10,
        "transfer_timing": 0.15,
    },
    "action_space_description": {
        "med_orders":    "Order 8 medications; rush delivery available at 2× cost",
        "staff_assign":  "Assign staff across 4 units; subject to strike availability",
        "bed_transfers": "Move patients between 4 units to optimize acuity matching",
        "discharges":    "Discharge patients to community care or step-down facilities",
    },
    "observation_space_description": {
        "patients":            "All patients across 4 units with risk scores",
        "med_inventory":       "8 med levels; disruption flag visible",
        "pending_med_orders":  "Orders with ETA and rush status",
        "current_schedule":    "Per-unit staffing; effective_available adjusted for strike",
        "recent_metrics":      "7-day KPI history",
        "expected_admissions": "3-day forecast (noisy during surge)",
    },
}

ALL_TASKS = {
    "task1_single_ward":  TASK1,
    "task2_multi_ward":   TASK2,
    "task3_surge_crisis": TASK3,
}
