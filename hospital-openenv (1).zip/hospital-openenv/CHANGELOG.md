# Changelog

All notable changes to this project will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
This project uses [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### Planned
- `gymnasium`-compatible wrapper (`gym.Env` subclass)
- Stable-Baselines3 example script
- LLM-as-agent integration example
- Task 4: Paediatric ward scenario
- Pydantic v2 models as optional dependency

---

## [1.0.0] — 2024-01-01

### Added

#### Core environment
- `HospitalEnv` class with full OpenEnv 1.0 API: `reset()`, `step()`, `state()`, `score()`
- Typed dataclass models for all state, action, and result objects (`models.py`)
- `model_dump()` on every dataclass for JSON-serialisable output
- Zero external dependencies — stdlib + numpy only

#### Simulation engine
- Stochastic patient arrivals: Poisson process with day-of-week and seasonal multipliers
- Four patient acuity levels: low / medium / high / critical
- Acuity-weighted length-of-stay distributions
- Per-patient medication consumption tied to acuity and category
- Deterioration and mortality risk as a function of staffing ratio and medication supply
- Natural discharge logic based on expected LOS
- 3-day noisy admission forecast for agent planning
- Three scenarios: `normal`, `surge` (+60% arrivals), `epidemic` (+120%)

#### Tasks
- **Task 1** — Single General Ward, 30 days, 4 medications, normal scenario (Easy)
- **Task 2** — Emergency + General + ICU, 60 days, 8 medications, transfers (Medium)
- **Task 3** — 4-ward network, 90 days, surge scenario, 5 crisis events (Hard)
  - Day 15: vancomycin + midazolam supply disruption
  - Day 30: staff strike (−40% pool, 6 days)
  - Day 45: blood product supply disruption
  - Day 60: mass casualty incident (+30 admissions)

#### Graders
- `Task1Grader`, `Task2Grader`, `Task3Grader` — all return `EpisodeScore` (0.0–1.0)
- Partial-credit sub-scores: service level, patient safety, cost efficiency, bed utilisation, transfer timing
- Crisis resilience weighting in Task 3 grader (40% weight on crisis-window performance)
- Letter grades: A (≥0.90) / B (≥0.80) / C (≥0.70) / D (≥0.55) / F

#### Reward function
- Dense shaped reward ∈ [−1, +1] per step
- Components: service level + patient safety − cost fraction + bed utilisation score
- Terminal bonus: +0.5 if final graded score ≥ 0.80
- Task-specific component weights

#### Baseline agents
- `RandomAgent` — uniform random valid actions (lower bound)
- `HeuristicAgent` — reorder-point inventory + ratio-based staffing + acuity transfers
- `GreedyAgent` — extends heuristic with 3-day forecast pre-ordering and surge staffing

#### Infrastructure
- `server.py` — stdlib-only HTTP server (no FastAPI/Gradio needed); dashboard at `/`
- `app.py` — FastAPI + Gradio app for Hugging Face Spaces deployment
- `Dockerfile` — HF Spaces–compatible container (non-root user, port 7860)
- `openenv.yaml` — full OpenEnv 1.0 specification
- `baseline/run_baseline.py` — reproducible multi-seed evaluation script with JSON output
- `baseline/expected_scores.json` — verified seed-42 scores for all agents × tasks

#### Tests
- 60 unittest tests covering full API contract (no pytest required)
- Test classes: ResetAPI, StepAPI, StateAPI, ScoreAPI, ObservationSchema, Reward, Graders, BaselineAgents, CrisisEvents, EnvUtilities

#### Documentation
- `README.md` — full API reference, observation/action space tables, setup, deployment
- `CONTRIBUTING.md` — dev setup, how to add tasks/agents, PR checklist
- `docs/` — architecture guide, reward design, environment design rationale

### Baseline scores (seed=42)

| Task | Random | Heuristic | Greedy |
|------|--------|-----------|--------|
| task1_single_ward | 0.948 | 0.969 | 0.955 |
| task2_multi_ward | 0.681 | 0.807 | 0.688 |
| task3_surge_crisis | 0.490 | 0.849 | 0.747 |

---

[Unreleased]: https://github.com/your-org/hospital-openenv/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/your-org/hospital-openenv/releases/tag/v1.0.0
