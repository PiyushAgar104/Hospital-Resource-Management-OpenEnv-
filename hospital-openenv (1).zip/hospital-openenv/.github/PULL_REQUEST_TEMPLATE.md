## Summary

<!-- One paragraph describing what this PR does and why. -->

## Type of change

- [ ] Bug fix
- [ ] New task
- [ ] New agent
- [ ] Documentation
- [ ] Other: ___

## Checklist

- [ ] All 60 existing tests pass: `python -m unittest tests.test_env -v`
- [ ] New functionality has tests (if applicable)
- [ ] `openenv.yaml` updated (if tasks or API changed)
- [ ] `CHANGELOG.md` updated under `[Unreleased]`
- [ ] No new external dependencies added to `environment/` or `baseline/`
- [ ] Docstrings added for new public methods

## Baseline scores (if agent or task changed)

Run `python -m baseline.run_baseline --seeds 3 --json` and paste the table:

```
Task                     │ Agent     │ Mean   │ Grade
─────────────────────────────────────────────────────
...
```

## Notes for reviewer

<!-- Anything the reviewer should pay particular attention to. -->
