# Environment Design

This document explains the clinical realism choices and modelling trade-offs made in the simulation.

---

## Real-world grounding

Hospital resource management is one of the most consequential optimisation problems in operations research. Every day, administrators must balance:

- **Medication procurement** — order too little and patients deteriorate; order too much and costs spike from holding and expiry
- **Staffing** — nurses and doctors are expensive and finite; understaffing directly increases adverse events
- **Patient flow** — wrong-unit patients occupy beds meant for higher-acuity cases
- **Crisis response** — supply chain disruptions, mass casualty events, and staff shortages are not hypothetical; they happen regularly

This environment models each of these using published clinical parameters as a guide (NHS bed occupancy targets, ICU nurse:patient ratios, DRG-style reimbursement, medication lead times).

---

## Patient flow model

### Arrivals

Arrivals follow a Poisson process with a time-varying rate:

```
λ_t = base_rate × dow_mult[t mod 7] × month_mult[month(t)] × scenario_mult
```

- `dow_mult`: Monday arrivals are ~15% higher than Sunday (real ED pattern)
- `month_mult`: Winter months are ~40% higher than summer (flu, respiratory)
- `scenario_mult`: 1.0 (normal) / 1.6 (surge) / 2.2 (epidemic)
- Random surge events: 3% daily probability of a 1.5–2.5× spike

Arrival rates by unit type:

| Unit | Base rate (patients/day) | Clinical basis |
|------|--------------------------|----------------|
| Emergency | 8.0 | Busy district general ED |
| General | 4.0 | Typical ward turnover |
| Surgery | 2.5 | Elective + emergency mix |
| ICU | 1.5 | Step-down from ED/surgery |

### Acuity distribution

Acuity at admission varies by unit:

| Acuity | Emergency | General | Surgery | ICU |
|--------|-----------|---------|---------|-----|
| Low | 30% | 50% | 20% | 5% |
| Medium | 40% | 35% | 45% | 20% |
| High | 20% | 12% | 30% | 40% |
| Critical | 10% | 3% | 5% | 35% |

### Length of stay

LOS is sampled from a normal distribution truncated at 1 day minimum:

| Acuity | Mean LOS | Std dev |
|--------|----------|---------|
| Low | 2.0 days | 1.0 |
| Medium | 4.5 days | 2.0 |
| High | 7.0 days | 3.0 |
| Critical | 12.0 days | 5.0 |

---

## Deterioration and mortality model

### Deterioration risk

Each patient has a base `deterioration_risk` set at admission. Each day:

```
risk_adjusted = base_risk
              × (1 + 0.02 × days_admitted)           # fatigue / HAI
              × max(0.5, 2.0 − staffing_ratio)        # understaffing
              × (1 + 3.0 × (1 − med_supply_ratio))    # medication shortfall
```

If `random() < risk_adjusted`, acuity worsens by one level and `deterioration_risk` increases by 10%.

### Mortality risk

Only CRITICAL patients face mortality risk:

```
mortality_risk = 0.05
              × max(1.0, 1.5 − staffing_ratio)
              × max(1.0, 2.0 − med_supply_ratio)
```

Capped at 40%. This means a critical patient with no staff and no meds has a 40% daily mortality risk — deliberately severe to penalise total neglect.

### Staffing ratio

```
staffing_ratio = min(
    actual_nurses  / required_nurses,
    actual_doctors / required_doctors
)
```

Required staff = `census × min_ratio × 1.0` (no safety factor built in here — that's the agent's job).

---

## Medication model

### Categories and criticality

| Category | Examples | Critical |
|----------|----------|---------|
| Antibiotic | Amoxicillin, Vancomycin | Vancomycin yes |
| Analgesic | Morphine, Ibuprofen | Morphine yes |
| Cardiac | Digoxin, Metoprolol | Digoxin yes |
| Sedative | Midazolam | Yes |
| Blood product | Packed RBCs | Yes |

Critical medications have 2–4× higher stockout penalties and contribute more strongly to deterioration risk when unavailable.

### Consumption

Daily consumption per patient is sampled with 15% coefficient of variation:

```
consumed = max(0, Normal(mean_need, mean_need × 0.15))
```

Needs scale with acuity. A CRITICAL patient uses ~5× the medications of a LOW patient.

### Ordering

| Parameter | Standard | Rush |
|-----------|---------|------|
| Lead time | medication-specific (1–3 days) | 1 day |
| Unit cost | list price | 2× list price |
| Max order | per-medication cap | same cap |

Supply disruptions (Task 3) block standard orders for specific medications for their duration. Rush orders bypass disruptions.

### Holding costs and expiry

All medications incur a daily holding cost. Shelf life is modelled implicitly — the environment does not track lot expiry, but holding costs proxy for the waste of over-ordering perishables.

---

## Economic model

### Revenue

Flat DRG-style reimbursement: **$350 per patient-day**.

Agent-triggered discharges earn an additional LOS-based payment: `$500 + LOS × $200`.

### Costs

| Cost type | Driver |
|-----------|--------|
| Medication procurement | quantity × unit cost (or 2× for rush) |
| Medication holding | inventory × holding_cost_per_day |
| Staffing | assigned staff × daily_cost |
| Stockout penalty | shortfall units × stockout_penalty |

### Cost-per-patient benchmark (used in grading)

| Task | Benchmark CPP |
|------|--------------|
| Task 1 | $1,800 |
| Task 2 | $2,500 |
| Task 3 | $3,200 |

These are calibrated so a competent heuristic agent scores approximately 0.7 on the cost_efficiency sub-score.

---

## Simplifications and limitations

This environment deliberately omits some real-world complexity to keep the action space manageable:

| Omitted | Reason |
|---------|--------|
| Medication lot expiry tracking | Would require per-lot inventory; adds complexity without proportional learning signal |
| Inter-hospital transfers | Out of scope for single-network scenarios |
| Diagnostic uncertainty | Agent observes true acuity; real-world diagnosis takes time |
| Shift scheduling (day/night) | Daily granularity; sub-day scheduling not modelled |
| Equipment and rooms | Beds are the binding constraint; equipment not tracked |
| Regulatory constraints | No formulary restrictions or prescribing limits |

These are intentional design choices, not bugs. Researchers who want higher fidelity can fork and extend `demand.py`.
